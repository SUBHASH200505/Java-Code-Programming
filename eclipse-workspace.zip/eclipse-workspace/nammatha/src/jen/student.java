package jen;

public class student {
	public static void main(String[] args) {
		tot(10,20,30,40,50);
		
	}
	public static void tot(int tamil,int english,int maths,int science,int social ) {
		 double res=tamil+english+maths+science+social;
		 avg(res);
		
		System.out.println(res);
		
	}
	public static void avg(double res) {
		
		 double avgs=res/5;
		 
		System.out.println(avgs);
		
	}

}



