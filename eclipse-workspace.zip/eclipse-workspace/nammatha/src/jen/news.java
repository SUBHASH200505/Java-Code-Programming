package jen;

import java.util.Scanner;

public class news {
	public static void main(String[] args) {
		/*System.out.println("S");
		Test(10,30);
		asc('a');
		asc(88);
		*/
		si(100,11,500);
	}
	public static void Test(int a,int b) {
		
	
		System.out.println(a+b);	
}
	public static void si(double a,int b,double r) {
		//System.out.println((int)c);
		System.out.println((a*b*r)/100);
	}
}
