package jen;

public class character {
	public static void main(String[] args) {
		chant('w');
	}
public static void chant(char ch) {
	String c=(ch>='0'&&ch<='9')?"it is int" :(ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')? "chasr ":"sp";
	System.out.println(c);
	
	
}
}
