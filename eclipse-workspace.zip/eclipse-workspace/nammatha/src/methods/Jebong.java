package methods;

public class Jebong
{
	public static void main(String[] args) {
		System.out.println("vanakkam da maapula");
		Salary.bon10(0);
		
		
	}

}
