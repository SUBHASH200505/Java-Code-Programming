package methods;

public class Demo 
{
	public static void main(String[] args)
	{
		Demo d=new Demo();
		d.test();
		
	}
	public static void test()
	{
		System.out.println("jebongg");
	}
		

	

}
