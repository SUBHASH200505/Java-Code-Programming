package methods;

public class Salary {
	public static void main(String[] args)
	{
		double r=bon10(55000);
		//double bonus=(salary>=50000)?salary*0.1:salary*0.05;
		System.out.println(r);
	}
	
	
	public static double bon10(int salary) 
	{
		double bonus=(salary>=50000)?salary*0.1:salary*0.05;
		//System.out.println(bonus);
		return bonus;
	}
	
	
	/*public static double bon5(int salary)
	{return salary*0.05;
		
	}*/
}
