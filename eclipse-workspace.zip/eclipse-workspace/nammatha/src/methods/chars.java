package methods;

public class chars {
	public static void main(String[] args) {
		
	}
public static char cho(char c)) {
	
}
}
