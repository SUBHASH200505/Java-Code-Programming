package methods;

public class Demo1 {
	public static void main(String[] args) {
		//Demo.s1=new Demo();
		//s1.test();
		Demo.test();
	}

}
