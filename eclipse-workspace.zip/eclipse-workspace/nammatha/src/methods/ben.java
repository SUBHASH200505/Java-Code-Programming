package methods;

public class ben {
public static void main(String[] args)
{
	System.out.println("ku");
}

}
