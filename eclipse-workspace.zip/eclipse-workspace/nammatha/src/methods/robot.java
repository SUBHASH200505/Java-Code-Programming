package methods;

public class robot 
{
	public static void main(String[] args) 
	{
		int bat =60;
		boolean l=false;
		String r=bat>=50&&!l ?goodBat():badBat();
		System.out.println(r);
	}
	
	public static String goodBat()
	{
		//System.out.println("ok");
		return "s";

	}
	public static String badBat() 
	{
		//System.out.println("no");
		return "no";
	}
}

