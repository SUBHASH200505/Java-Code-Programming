package methods;

public class Qwen {
	public static void show() {
		System.out.println("hlo");
	}
	public static void show(String s1) {
		System.out.println(s1);
}
	public static void show(String s2,String s3) {
		System.out.println(s2+" "+s3);
	}
}