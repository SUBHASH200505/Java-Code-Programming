package methods;

public class kavin {
public static void main(String[] args) {
	Qwen q=new Qwen();
	q.show();
	q.show("good morning");
	q.show("hey karh","how was day");
}
}
