/*package methods;

public class addition {
	public static void main(String[] args) {
		System.out.println(add(10,20));
	}
	public static int add(int a,int b) {
		return a+b;
	}

}*/
public class addition
{
	public static void main(String[] args) {
		System.out.println(ascii('c'));
	}
	public static int ascii(char a)
	{
		return a;
	}
}
