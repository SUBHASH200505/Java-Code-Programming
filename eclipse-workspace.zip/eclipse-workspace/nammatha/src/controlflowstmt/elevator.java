package controlflowstmt;
import java.util.Scanner;
public class elevator {
	public static void maxcap()
	{
		int capacity=500,currentwt ;
		
		Scanner s=new Scanner(System.in);
		System.out.println("enter" );
		currentwt=s.nextInt();
		
		
		if(currentwt>capacity)
		{
			System.out.println("overload");
		}
		if(currentwt<capacity)
		{System.out.println("nooverload");
		
	}
		
}}
