package controlflowstmt;

public class elevs {
	public static void main(String[] args) {
		elevator e=new elevator();
		e.maxcap();
	}

}
