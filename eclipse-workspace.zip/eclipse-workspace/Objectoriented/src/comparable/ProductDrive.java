package comparable;

import java.util.Arrays;

public class ProductDrive {
    public static void main(String[] args) {
        Product p1 = new Product("Book", 101, 5, 20.0);
        Product p2 = new Product("Pen", 105, 10, 5.0);
        Product p3 = new Product("Pencil", 102, 3, 10.0);
        Product p4 = new Product("Note", 104, 2, 15.0);

        Product[] arr = {p1, p2, p3, p4};

        BrandComparator b1 = new BrandComparator();
        QuantityComparator b2 = new QuantityComparator();
        PriceComparator b3 = new PriceComparator();

        // Uncomment one of the sorting methods as needed:
        // Arrays.sort(arr, b1); // Sort based on brand
        // Arrays.sort(arr, b2); // Sort based on quantity
        // Arrays.sort(arr, b3); // Sort based on price
        // Arrays.sort(arr); // Sort based on id (if Product implements Comparable)

        for (Product p : arr) {
            System.out.println(p);
        }
    }
}
