package comparable;
import java.util.*;
public class QuantityComparator implements Comparator{
	public int compare(Object o1, Object o2) {
		Product p1 = (Product)o1;
		Product p2 = (Product)o2;
		
		return p1.quantity-p2.quantity;
	}
}
