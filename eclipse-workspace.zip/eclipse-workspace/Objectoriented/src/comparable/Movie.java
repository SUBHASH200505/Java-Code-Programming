package comparable;

public class Movie {
String name;
String actor;
double duration;
int year;
Movie(String name,String actor,double duration,int year)
{
	this.name=name;
	this.actor=actor;
	this.duration=duration;
	this.year=year;
}
public String toString() {
	return "name"+" "+name+" "+"actor"+" "+actor+" "+"duration"+" "+duration+" "+"year"+" "+year;
}

}
