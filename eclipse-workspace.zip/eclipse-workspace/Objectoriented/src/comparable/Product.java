package comparable;

public class Product implements Comparable{
	String brand;
	int id;
	int quantity;
	double price;
	
	Product(String brand,int id,int quantity,double price)
	{
		this.brand=brand;
		this.id=id;
		this.quantity=quantity;
		this.price=price;
	}
	
	@Override
	public String toString() {
		return "Product [brand=" + brand + ", id=" + id + ", quantity=" + quantity + ", price=" + price + "]";
	}
	
	public int compareTo(Object o)
	{
		Product p = (Product)o;
		if(this.id==p.id)
			return this.brand.compareTo(p.brand);
		return this.id-p.id;
	}

}
