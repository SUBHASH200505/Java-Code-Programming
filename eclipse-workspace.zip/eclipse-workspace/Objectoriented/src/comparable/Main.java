package comparable;
import java.util.*;
public class Main {
public static void main(String[] args) {
	ArrayList<Movie> ar=new ArrayList<>();
	ar.add(new Movie("XYZ","ABC",2.5,2024));
	ar.add(new Movie("ABC","ERT",3.0,2023));
	ar.add(new Movie("VXC","MKF",3.0,2025));
 double key=2.5;
	Movie s1=null;
	String s2="ABC";
	System.out.println(ar.remove(s2));
	for(Movie s:ar)
	{
		if(key==s.duration)
		{
			s1=s;
			break;
		}
	}
	if(s1!=null)
	{
		System.out.println("present");
	}
	else
	{
		System.out.println("Not present");
	}	
	for(int i=0;i<ar.size();i++)
	{
		System.out.println(ar.get(i));
	}
}
}
