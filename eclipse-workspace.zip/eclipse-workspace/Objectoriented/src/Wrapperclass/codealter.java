package Wrapperclass;
import java.util.*;
public class codealter {
public static void main(String[] args) {
	String name="MOVE#TO##THE#FRONT";
	System.out.println(modify(name));
}
public static String modify(String name)
{
   StringBuffer str=new StringBuffer(name);
   StringBuffer str1=new StringBuffer();
   for(int i=0;i<str.length();i++)
   {
	   if(str.charAt(i)=='#')
	   {
		   str1.append(str.charAt(i));
		   str.replace(i, i+1,"0");
	   }
   }
   for(int i=0;i<str.length();i++)
   {
	   if(str.charAt(i)!='0')
	   {
		   str1.append(str.charAt(i));
	   }
   }
   return str1.toString();
}
}
