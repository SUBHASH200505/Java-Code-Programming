package Wrapperclass;

public class ex1 {
public static void main(String[] args) {
	boolean b=Boolean.parseBoolean("Hello");
	System.out.println(b);

}
}
