package hybrid;

public class F extends E{
	public static void main(String[] args) {
		F f1=new F();
		System.out.println(f1 instanceof C);
	}

}
