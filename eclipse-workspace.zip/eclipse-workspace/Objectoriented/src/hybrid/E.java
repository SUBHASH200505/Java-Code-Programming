package hybrid;

public class E extends D{

}
