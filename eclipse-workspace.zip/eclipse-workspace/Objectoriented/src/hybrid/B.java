package hybrid;

public class B extends A{

}
