package hybrid;

public class D extends C{

}
