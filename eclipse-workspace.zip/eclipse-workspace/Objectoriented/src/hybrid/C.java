package hybrid;

public class C extends A{

}
