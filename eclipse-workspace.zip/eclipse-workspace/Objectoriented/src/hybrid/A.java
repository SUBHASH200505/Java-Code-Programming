package hybrid;

public class A {

}
