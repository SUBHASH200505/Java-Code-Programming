/**
 * 
 */
/**
 * 
 */
module Objectoriented {
}