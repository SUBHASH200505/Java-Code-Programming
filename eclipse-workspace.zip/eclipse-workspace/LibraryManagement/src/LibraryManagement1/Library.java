package LibraryManagement1;

import java.util.*;

public class Library {
    ArrayList<Book> books = new ArrayList<>();
    ArrayList<User> users = new ArrayList<>();

    public void addBook(Book book) {
        books.add(book);
    }

    public boolean removeBook(String title) {
        for (Book b : books) {
            if (b.title.equalsIgnoreCase(title)) {
                books.remove(b);
                return true;
            }
        }
        return false;
    }

    public void showAllBooks() {
        for (Book b : books) {
            System.out.println(b);
        }
    }

    public boolean isBookPresent(String name) {
        for (Book b : books) {
            if (b.title.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    public Book borrowBook(String name) {
        for (Book b : books) {
            if (b.title.equalsIgnoreCase(name) && !b.isBorrowed) {
                b.isBorrowed = true;
                return b;
            }
        }
        return null;
    }

    public void returnBook(Book book) {
        book.isBorrowed = false;
    }

    public void showAllUsers() {
        for (User u : users) {
            System.out.println("User: " + u.name + " | Borrowed: " + (u.borrowedBook != null ? u.borrowedBook.title : "None"));
        }
    }

    public void sortBooksById() {
        books.sort(Comparator.comparingInt(b -> b.id));
        showAllBooks();
    }

    public void sortBooksByRating() {
        books.sort((a, b) -> Double.compare(b.rating, a.rating));
        showAllBooks();
    }

    public void sortBooksByTitle() {
        books.sort(Comparator.comparing(b -> b.title));
        showAllBooks();
    }

    public void registerUser(User user) {
        users.add(user);
        System.out.println("User registered.");
    }

    public User loginUser(String name, String password) {
        for (User u : users) {
            if (u.name.equals(name) && u.password.equals(password)) return u;
        }
        return null;
    }
}
