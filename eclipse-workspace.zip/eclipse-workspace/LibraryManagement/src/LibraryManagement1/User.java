package LibraryManagement1;

import java.util.Scanner;

public class User {
    String name;
    String password;
    Book borrowedBook = null;

    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public void showAllBooks(Library library) {
        library.showAllBooks();
    }

    public void getBook(String name, Library library) {
        if (borrowedBook != null) {
            System.out.println("You already borrowed a book.");
            return;
        }
        Book book = library.borrowBook(name);
        if (book != null) {
            borrowedBook = book;
            System.out.println("You borrowed: " + book.title);
        } else {
            System.out.println("Book not available.");
        }
    }

    public void returnBook(Library library) {
        if (borrowedBook == null) {
            System.out.println("No book to return.");
        } else {
            library.returnBook(borrowedBook);
            System.out.println("Returned: " + borrowedBook.title);
            borrowedBook = null;
        }
    }

    public void editDetails() {
        Scanner sc = new Scanner(System.in);
        System.out.print("New Name: ");
        name = sc.nextLine();
        System.out.print("New Password: ");
        password = sc.nextLine();
        System.out.println("Details updated.");
    }

    public void sortBasedOnId(Library library) {
        library.sortBooksById();
    }

    public void sortBasedOnRating(Library library) {
        library.sortBooksByRating();
    }

    public void sortBasedOnTitle(Library library) {
        library.sortBooksByTitle();
    }
}
