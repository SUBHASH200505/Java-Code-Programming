package LibraryManagement1;

public class StackDriver {
public static void main(String[] args) {
	Stack s=new Stack();
	s.isFull(5);
}
}
