package LibraryManagement1;

public class Librarian {
    public void addBook(Library library, Book book) {
        library.addBook(book);
        System.out.println("Book added.");
    }

    public void removeBook(Library library, String title) {
        boolean result = library.removeBook(title);
        if (result)
            System.out.println("Book removed.");
        else
            System.out.println("Book not found.");
    }

    public void showAllUsers(Library library) {
        library.showAllUsers();
    }

    public void showAllBooks(Library library) {
        library.showAllBooks();
    }

    public boolean isBookPresent(Library library, String name) {
        return library.isBookPresent(name);
    }
}
