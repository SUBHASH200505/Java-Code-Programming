package LibraryManagement1;

public class Student {

}
