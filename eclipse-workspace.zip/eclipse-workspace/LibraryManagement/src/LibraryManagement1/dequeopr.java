package LibraryManagement1;

import java.util.ArrayDeque;

public class dequeopr {
public static void main(String[] args) {
	ArrayDeque<Integer> str=new ArrayDeque<>();
	str.add(10);
	str.add(20);
	str.addFirst(20);
	str.addLast(40);
	str.removeFirst();
	str.contains(10);
	System.out.println(str);
}
}
