package LibraryManagement1;

import java.util.Scanner;

public class Drive {	
    static final String LIBRARIAN_USERNAME = "admin";
    static final String LIBRARIAN_PASSWORD = "admin123";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Library library = new Library();
        Librarian librarian = new Librarian();

        while (true) {
            System.out.println("\n1. Register User\n2. Login User\n3. Login Librarian\n4. Exit");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter password: ");
                    String pass = sc.nextLine();
                    User u = new User(name, pass);
                    library.registerUser(u);
                }
                case 2 -> {
                    System.out.print("Username: ");
                    String name = sc.nextLine();
                    System.out.print("Password: ");
                    String pass = sc.nextLine();
                    User u = library.loginUser(name, pass);
                    if (u != null) {
                        System.out.println("Login successful. Welcome, " + u.name + "!");
                        userMenu(u, library);
                    } else {
                        System.out.println("Invalid credentials.");
                    }
                }
                case 3 -> {
                    System.out.print("Admin username: ");
                    String user = sc.nextLine();
                    System.out.print("Password: ");
                    String pass = sc.nextLine();
                    if (user.equals(LIBRARIAN_USERNAME) && pass.equals(LIBRARIAN_PASSWORD)) {
                        System.out.println("Librarian logged in.");
                        librarianMenu(librarian, library);
                    } else {
                        System.out.println("Invalid librarian credentials.");
                    }
                }
                case 4 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    static void userMenu(User u, Library library) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("""
                \n1. View Books
                2. Borrow Book
                3. Return Book
                4. Edit Profile
                5. Sort by ID
                6. Sort by Rating
                7. Sort by Title
                8. Logout""");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> u.showAllBooks(library);
                case 2 -> {
                    System.out.print("Enter book title to borrow: ");
                    String title = sc.nextLine();
                    u.getBook(title, library);
                }
                case 3 -> u.returnBook(library);
                case 4 -> u.editDetails();
                case 5 -> u.sortBasedOnId(library);
                case 6 -> u.sortBasedOnRating(library);
                case 7 -> u.sortBasedOnTitle(library);
                case 8 -> {
                    System.out.println("Logging out...");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    static void librarianMenu(Librarian librarian, Library library) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("""
                \n1. Add Book
                2. Remove Book
                3. Show All Books
                4. Show All Users
                5. Check if Book Exists
                6. Logout""");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> {
                    System.out.print("Title: ");
                    String title = sc.nextLine();
                    System.out.print("Author: ");
                    String author = sc.nextLine();
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    System.out.print("Rating: ");
                    double rating = sc.nextDouble();
                    librarian.addBook(library, new Book(title, author, id, rating));
                }
                case 2 -> {
                    System.out.print("Book title to remove: ");
                    String title = sc.nextLine();
                    librarian.removeBook(library, title);
                }
                case 3 -> librarian.showAllBooks(library);
                case 4 -> librarian.showAllUsers(library);
                case 5 -> {
                    System.out.print("Book title: ");
                    String title = sc.nextLine();
                    System.out.println(librarian.isBookPresent(library, title) ? "Book exists." : "Book not found.");
                }
                case 6 -> {
                    System.out.println("Logging out...");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}
