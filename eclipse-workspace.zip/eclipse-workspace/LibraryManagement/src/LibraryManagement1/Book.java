package LibraryManagement1;
import java.util.Scanner;

public class Book {
    String title;
    String author;
    int id;
    double rating;
    boolean isBorrowed = false;

    public Book(String title, String author, int id, double rating) {
        this.title = title;
        this.author = author;
        this.id = id;
        this.rating = rating;
    }

    public String toString() {
        return "[" + id + "] " + title + " by " + author + " | Rating: " + rating + " | " + (isBorrowed ? "Borrowed" : "Available");
    }
}
