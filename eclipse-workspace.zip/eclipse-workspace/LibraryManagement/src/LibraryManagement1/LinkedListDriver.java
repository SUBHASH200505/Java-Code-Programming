package LibraryManagement1;
import java.util.Scanner;

public class LinkedListDriver {
    public static void main(String[] args) {
        LinkedList l = new LinkedList(); 
        Scanner sc = new Scanner(System.in);
        while(true)
        {
        System.out.println("Enter 1 Adding ");
        System.out.println("Enter 2 deleting last");
        System.out.println("Enter 3 print");
        System.out.println("Enter 4 tostring");
        System.out.println("Enter 5 exit");
        System.out.println("Enter 6 search");
        System.out.println("Enter 7 delete element");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                System.out.println("Enter the value to add in the linked list:");
                int s = sc.nextInt();
                l.add(s);
                break;

            case 2:
                l.delete();
                break;

            case 3:
                l.print();
                break;

            case 4:
                System.out.println(l.toString()); 
                break;
            case 5:
            	System.out.println("Exiting the program");
            	sc.close();
            	return;
            case 6:
            	System.out.println("Enter the data to search");
            	int value=sc.nextInt();
            	System.out.println(l.search(value));
            	break;
            case 7:
            	System.out.println("Enter the data to delete");
            	int value1=sc.nextInt();
            	l.delete1(value1);
            	break;
            	
            default:
                System.out.println("Invalid input");
                break;
        }
        }

       
    }
}
