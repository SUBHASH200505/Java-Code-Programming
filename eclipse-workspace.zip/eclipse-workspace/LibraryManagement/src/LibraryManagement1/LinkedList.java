package LibraryManagement1;

public class LinkedList {
private class Node
{
	int data;
	Node next;
	Node(int data)
	{
		this.data=data;
	}
}
private Node head;
public boolean isEmpty()
{
	return head==null;
}
public void add(int data)
{
	Node temp=head;
	Node newnode=new Node(data);
	if(isEmpty())
	{
		head=newnode;
		return;
	}
	
	else
	{
		while(temp.next!=null)
		{
			temp=temp.next;
		}
		temp.next=newnode;
	}
}
public void print()
{
	Node temp=head;
	if(isEmpty()){
		System.out.println("List is empty");
		return;
	}
	else
	{
	while(temp!=null)
	{
		System.out.print(temp.data+"--->");
		temp=temp.next;
	}
	System.out.println(temp);
	}
}
public Node search(int data) {
    Node temp = head;

    if (isEmpty()) {
        System.out.println("LinkedList is empty");
        return null;
    }

    while (temp != null) {
        if (temp.data == data)
            return temp;
        temp = temp.next;
    }

    return null; 
}
public void update(int data,int data1)
{
	Node temp=head;
	while(temp!=null)
	{
		if(temp.data==data)
		{
			temp.data=data1;
		}
		temp=temp.next;
	}
}
public void delete()
{
	Node temp=head;
	if(head.next==null)
	{
		head=null;
	}
	else if(isEmpty())
	{
		System.out.println("LinkedList is Empty");
	}
	else
	{
	while(temp.next.next!=null)
	{
		temp=temp.next;
	}
	temp.next=null;
	}
}
public void delete1(int data) {
    if (head == null) {
        System.out.println("LinkedList is empty");
        return;
    }
    if (head.data == data) {
        head = head.next;
        return;
    }
    Node temp = head;
    while (temp.next != null) {
        if (temp.next.data == data) {
            temp.next = temp.next.next; 
            return; 
        }
        temp = temp.next; 
    }
    System.out.println("Element not found");
}
public String toString()
{
	Node temp=head;
	if(isEmpty())
	{
		return "[ Empty ]";
	}
	else
	{
		System.out.print("[");
		while(temp!=null)
		{
			System.out.print(temp.data);
			if(temp.next!=null)
			{
				System.out.print(",");
			}
			temp=temp.next;
		}
		System.out.print("]");
		return "";
	}
}


}
