package LibraryManagement1;

public class Stack {
int stack[];
int top;
public void isFull(int size)
{
	stack[size];
	top=-1;
	if(top==s)
}
}
