package LibraryManagement1;
import java.util.*;
import java.io.*;
public class FileHandling {
public static void main(String[] args) throws IOException {
	String path="D:\\New folder\\hello/rock.txt";
	File f1=new File(path);
	if(f1.createNewFile())
		System.out.println("File is created");
	else
		System.out.println("File is not created");
	
}
}
