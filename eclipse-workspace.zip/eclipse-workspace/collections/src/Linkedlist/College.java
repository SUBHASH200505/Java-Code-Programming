package Linkedlist;

public class College {
	public static void main(String[] args)
	{
		Student[] students=new Student[5];
		
	}

}
