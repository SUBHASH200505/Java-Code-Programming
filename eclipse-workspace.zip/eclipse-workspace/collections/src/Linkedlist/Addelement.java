package Linkedlist;
import java.util.*;
public class Addelement {
public static void main(String[] args) {
	LinkedList<Integer>l=new LinkedList<>();
	l.add(10);
    l.add(20);
    l.add(30);
    l.addFirst(40);
    l.addLast(60);
//    l.remove(2);
//    l.removeFirst();
//    l.removeLast();
//    System.out.println(l);
//    System.out.println(l.get(1));
Collections.sort(l);
System.out.println(l);
}
}
