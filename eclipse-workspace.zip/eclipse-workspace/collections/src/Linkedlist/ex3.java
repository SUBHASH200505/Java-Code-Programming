package Linkedlist;
import java.util.*;
public class ex3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int sum=0;
		int[] arr=new int[a];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();	
		}
		int b=sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			Arrays.sort(arr);
			arr[i]=arr[i]*-1;
		}
		for(int i=0;i<arr.length;i++)
		{
		sum+=arr[i];	
		}
		sysopackage Wrapperclass;
		import java.util.*;

		 class numberconverter {
		    public static void main(String[] args) {
		        Scanner sc = new Scanner(System.in);
		        System.out.print("Enter a number: ");
		        int a = sc.nextInt();
		        int original = a; 
		        String result1 = "";
		        while (a != 0) {
		            int digit = a % 10;
		            a = a / 10;
		            switch (digit) {
		                case 0: result1 += "Zero "; break;
		                case 1: result1 += "One "; break;
		                case 2: result1 += "Two "; break;
		                case 3: result1 += "Three "; break;
		                case 4: result1 += "Four "; break;
		                case 5: result1 += "Five "; break;
		                case 6: result1 += "Six "; break;
		                case 7: result1 += "Seven "; break;
		                case 8: result1 += "Eight "; break;
		                case 9: result1 += "Nine "; break;
		            }
		        }

		        String[] words = result1.trim().split(" ");
		        System.out.print("Number in words: ");
		        for (int i = words.length - 1; i >= 0; i--) {
		            System.out.print(words[i] + " ");
		        }
		    }
		}

	}

}
