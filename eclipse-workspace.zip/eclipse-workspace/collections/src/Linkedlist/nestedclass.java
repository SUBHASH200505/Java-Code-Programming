package Linkedlist;

public class nestedclass {
	static class sample{
		static int a;
		int b;
	}
	class test{
		static int c;
		int d;
	}
	
	public static void main(String[] args) {
		System.out.println(sample.a);
		System.out.println(nestedclass.sample.a);
		nestedclass n=new nestedclass();
		System.out.println();
	}
}
