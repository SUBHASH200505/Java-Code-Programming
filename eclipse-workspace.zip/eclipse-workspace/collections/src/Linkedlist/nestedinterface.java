package Linkedlist;

public class nestedinterface {

}
