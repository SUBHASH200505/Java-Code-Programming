package Linkedlist;

import java.util.Arrays;

public class addone {
    public static void main(String[] args) {
        int[] arr = {1,2,4}; 
        int value = arr[arr.length - 1] + 1;

        if (value == 10) {
            int[] arr1 = new int[arr.length + 1];
            arr1[arr1.length - 1] = 0;
            arr1[arr1.length - 2] = 1;

            for (int i = 0; i < arr.length - 1; i++) {
                arr1[i] = arr[i];
            }
            System.out.println(Arrays.toString(arr1));
        } else {
            arr[arr.length - 1] = value;
            System.out.println(Arrays.toString(arr));
        }
    }
}
