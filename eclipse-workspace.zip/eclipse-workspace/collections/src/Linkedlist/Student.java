package Linkedlist;

public class Student {
int roll;
String name;
double cgpa;
public Student(int roll,String name,double cgpa)
{
	this.roll=roll;
	this.name=name;
	this.cgpa=cgpa;
}
public String toString()
{
	return "Name :"+this.name+"||"+"Roll no :"+this.roll+"||"+"cgpa :"+this.cgpa;
}
public int compareTo(Student s)
{
	if(this.cgpa!=s.cgpa)
		return Double.compare(s.cgpa,this.cgpa);
	
	
}
}
