package hashset;

public class Student {
	String name;
	int id;
	Student(String name,int id)
	{
		super();
		this.name=name;
		this.id=id;
	}

}
