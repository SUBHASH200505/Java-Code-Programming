package hashset;
import java.util.*;
public class Linkedhash {
public static void main(String[] args) {
	LinkedHashSet<Integer> ah=new LinkedHashSet<>();
	ah.add(12);
	ah.add(20);
	System.out.println(ah);
	Collections.sort(ah);
	
}
}
