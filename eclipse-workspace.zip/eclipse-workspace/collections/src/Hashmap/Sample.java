package Hashmap;
import java.util.*;
public class Sample {
public static void main(String[] args) {
	HashMap<Integer,String>map1=new HashMap<Integer,String>();
	HashMap<Integer,String>map2=new HashMap<Integer,String>();
	map1.put(10, "ABC");
	map1.put(20, "BCD");
	map1.put(10,"CDE");
	System.out.println(map1);
	Set<Integer> set=map1.keySet();
	System.out.println("--------Keys-------");
	for(Integer a:set)
	{
		System.out.println(a);
	}
	Collection<String> list=map1.values();
	System.out.println("---------values--------");
	for(String s:list)
	{
		System.out.println(s);
	}
}
}
