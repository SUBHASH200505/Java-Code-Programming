package Hashmap;
import java.util.*;
public class keyvalue {
public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
String[] arr=new String[a];
for(int i=0;i<arr.length;i++)
{
	arr[i]=sc.next();
}
HashMap<Integer,String> h=new HashMap<Integer,String>();
for(int i=0;i<arr.length;i++)
{
	h.put(i, arr[i]);
}
System.out.println(h);
}
}
