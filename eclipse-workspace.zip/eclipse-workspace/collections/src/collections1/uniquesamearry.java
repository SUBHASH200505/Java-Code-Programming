package collections1;
import java.util.*;

public class uniquesamearry {
    public static void main(String[] args) {
        ArrayList<Integer> str = new ArrayList<>();
        System.out.println("Enter the size of the array");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();

        for (int i = 0; i < a; i++) {
            str.add(sc.nextInt());
        }

        for (int i = 0; i < str.size(); i++) {
            int count = 0;
            for (int j = 0; j < str.size(); j++) {
                if (i != j && str.get(i).equals(str.get(j))) {
                	str.set(j, 0);
                    count++;
                }
            }
            if (count == 0) {
                str.remove(i);
                i--; 
            }
        }

        System.out.println(str);
    }
}
