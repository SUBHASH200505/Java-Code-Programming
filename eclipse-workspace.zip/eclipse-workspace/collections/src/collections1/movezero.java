package collections1;
import java.util.*;

public class movezero {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedList<Integer> str = new LinkedList<Integer>();
        int a = sc.nextInt();
        int count = 0;
        for (int i = 0; i < a; i++) {
            str.add(sc.nextInt());
        }
        Iterator<Integer> itr = str.iterator();
        while (itr.hasNext()) {
            if (itr.next() == 0) {
                itr.remove();
                count++;
            }
        }
        for (int i = 0; i < count; i++) {
            str.add(0);
        }
        System.out.println(str);
    }
}
