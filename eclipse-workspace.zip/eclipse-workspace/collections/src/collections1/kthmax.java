package collections1;
import java.util.*;
public class kthmax {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter size of the array");
	int a=sc.nextInt();
	int[] arr=new int[a];
	for(int i=0;i<arr.length;i++)
	{
		arr[i]=sc.nextInt();			
	}
	System.out.println("Enter the kth value");
	int k=sc.nextInt();
	LinkedList<Integer> set=new LinkedList<>();
	for(int i=0;i<arr.length;i++)
	{
		set.add(arr[i]);
	}
	Collections.sort(set);
	System.out.println(set.get(k-1));
	
}
}
