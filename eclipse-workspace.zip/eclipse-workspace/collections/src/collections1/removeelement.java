package collections1;
import java.util.*;

public class removeelement {
    public static void main(String[] args) {
        ArrayList<Integer> str = new ArrayList<>();
        System.out.println("Enter the size of the array");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();

        for (int i = 0; i < a; i++) {
            str.add(sc.nextInt());
        }

        System.out.println("Enter the limit");
        int b = sc.nextInt();
        for (int i = str.size() - 1; i >= 0; i--) {
            int value = str.get(i);
            if (value < b) {
                str.remove(i); 
            }
        }

        System.out.println(str);
    }
}
