package collections1;

public class Student {
String name;
int id;
int age;
Student(String name,int id,int age)
{
	this.name=name;
	this.id=id;
	this.age=age;
}
public String toString()
{
	return name+" "+id+" "+age+" ";
}
}
