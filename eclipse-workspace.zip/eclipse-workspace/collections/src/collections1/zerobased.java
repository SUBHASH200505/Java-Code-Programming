package collections1;
import java.util.*;

public class zerobased {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(); // size of array
        int[] arr = new int[a];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == 0 && i + 1 < arr.length) {
                arr[i + 1] = 0;
            }
        }
        System.out.println("Modified array:");
        for (int value : arr) {
            System.out.print(value + " ");
        }
    }
}
