package collections1;
import java.util.*;

public class unique {
    public static void main(String[] args) {
        ArrayList<Integer> str = new ArrayList<>();
        System.out.println("Enter the size of the array");
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();

        for (int i = 0; i < a; i++) {
            str.add(sc.nextInt());
        }

        ArrayList<Integer> str1 = new ArrayList<>();

        for (int i = 0; i < str.size(); i++) {
            for (int j = i + 1; j < str.size(); j++) {
                int value = str.get(i);
                int value1 = str.get(j);
                if (value == value1 && !str1.contains(value1)) {
                    str1.add(value1);
                }
            }
        }

        System.out.println(str1);
    }
}
