package collections1;

import java.util.ArrayList;

public class Studentdriver {
	public static void main(String[] args) {
		ArrayList<Student> str=new ArrayList<Student>();
		Student a=new Student("thiru",123,20);
		str.add(a);
		str.add(new Student("Rock",234,21));
		str.add(new Student("Rose",345,22));
		//System.out.println(str);
		ArrayList<Student>str1=new ArrayList<Student>();
		str1.add(new Student("balaji",456,22));
		str1.add(new Student("Rockstar",567,23));
//		System.out.println(str1);
//		str.addAll(str1);
//		System.out.println(str);
		for(Student s:str)
		{
			System.out.println(s);
		}
		
	}

}
