package collections1;
import java.util.*;

public class Maximum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();

        ArrayList<Integer> arr1 = new ArrayList<>();

        for (int i = 0; i < a; i++) {
            arr1.add(sc.nextInt());
        }

        int max = arr1.get(0);
        int min = arr1.get(0);

        for (int i = 1; i < arr1.size(); i++) {
            if (arr1.get(i) > max) {
                max = arr1.get(i);
            }
            if (arr1.get(i) < min) {
                min = arr1.get(i);
            }
        }

        System.out.println("Maximum = " + max);
        System.out.println("Minimum = " + min);
        System.out.println(arr1);
    }
}
