package collections1;
import java.util.*;
public class arraylist2 {
public static void main(String[] args) {
	ArrayList<Integer> a=new ArrayList<>();
	a.add(10);
	a.add(20);
	a.add(40);
	System.out.println(a);
	ArrayList<Integer> b=new ArrayList<>();
	b.add(60);
	b.add(70);
	a.addAll(b);
	System.out.println(a);
	
}
}
