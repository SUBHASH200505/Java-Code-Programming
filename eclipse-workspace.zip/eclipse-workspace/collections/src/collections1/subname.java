package collections1;
import java.util.*;
public class subname {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			String string=sc.next();
			String substring=sc.next();
			int count=0;
			for(int i=0;i<string.length();i++)
			{
				for(int j=i+1;j<string.length();j++)
				{
					String key=string.substring(i,j);
					if(key.equals(substring))
						count++;
				}
			}
			System.out.println(count);
		}

	}

