package collections1;
import java.util.*;
public class firstchar {
public static void main(String[] args) {
	ArrayList<String> str=new ArrayList<>();
	str.add("hello");
	str.add("hi");
	str.add("welcome");
	ArrayList<Character> st=new ArrayList<>();
	for(String s:str)
	{
	st.add(s.charAt(0));
		
		
	}
	System.out.println(st);
}
}
