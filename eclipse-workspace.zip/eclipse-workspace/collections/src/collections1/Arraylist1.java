package collections1;
import java.util.*;
public class Arraylist1 {
public static void main(String[] args) {
	ArrayList<Integer> ar=new ArrayList<>();
	ar.add(10);
	ar.add(20);
	ar.add(5);
	ar.add(2);
	Collections.sort(ar,Collections.reverseOrder());
	System.out.println(ar); 
}
}
