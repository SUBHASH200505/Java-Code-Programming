package collections1;
import java.util.*;

public class reverse {
    public static void main(String[] args) {
        ArrayList<String> str = new ArrayList<>();
        str.add("hi");
        str.add("hello");
        str.add("welcome");

        for (int i = 0; i < str.size(); i++) {
            String original = str.get(i);
            StringBuffer reversed = new StringBuffer(original).reverse();
            str.set(i, reversed.toString()); 
        }

        System.out.println("Reversed strings list: " + str);
    }
}
