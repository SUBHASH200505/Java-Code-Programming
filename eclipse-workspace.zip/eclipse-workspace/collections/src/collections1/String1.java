package collections1;
import java.util.*;
import java.util.Collection;
public class String1 {
public static void main(String[] args) {
	ArrayList<String> str=new ArrayList<>();
	str.add("Hello");
	str.add("World");
	str.add("Welcome");
	Collections.sort(str);
	System.out.println(str);
}
}
