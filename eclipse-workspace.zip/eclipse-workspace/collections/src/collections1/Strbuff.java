package collections1;
import java.util.*;
public class Strbuff {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.next();
	char[] ar=s.toCharArray();
	StringBuffer st=new StringBuffer();
	for(char ch:ar)
	{
		if(ch=='i')
		{
			st.reverse();
		}
		else
			st.append(ch);
	}
	System.out.println(st);
}
}
