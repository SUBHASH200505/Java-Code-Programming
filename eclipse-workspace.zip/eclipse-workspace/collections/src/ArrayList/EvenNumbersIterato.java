package ArrayList;
import java.util.ArrayList;
import java.util.Iterator;

public class EvenNumbersIterator {
    public static void main(String[] args) {
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(10);
        numbers.add(15);
        numbers.add(20);
        numbers.add(25);
        numbers.add(30);
        numbers.add(35);
        numbers.add(40);

        // Use Iterator to traverse and print only even numbers
        Iterator<Integer> iterator = numbers.iterator();
        System.out.println("Even numbers in the list:");
        while (iterator.hasNext()) {
            int num = iterator.next();
            if (num % 2 == 0) { // Check if the number is even
                System.out.print(num + " ");
            }
        }
    }
}