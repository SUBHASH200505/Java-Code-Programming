package ArrayList;

import java.util.ArrayList;

public class LongestWordFinder {
	public static void main(String[] args) {

		ArrayList<String> words = new ArrayList<>();
		words.add("Java");
		words.add("Programming");
		words.add("Language");
		words.add("Code");
		words.add("Algorithm");

		String longestWord = "";
		for (String word : words) {
			if (word.length() > longestWord.length()) {
				longestWord = word;
			}
		}

		System.out.println("Longest Word: " + longestWord);
	}
}
