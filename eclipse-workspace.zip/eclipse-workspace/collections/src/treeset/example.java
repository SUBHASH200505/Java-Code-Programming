package treeset;
import java.util.*;
class example implements Comparable<example> {
String name;
int id;
public example(String name,int id)
{
	super();
	this.name=name;
	this.id=id;
	
}
public String toString()
{
	return name+" "+id;
}
@Override
public int compareTo(example o) {
	return this.name.compareTo(o.name);
}

}
