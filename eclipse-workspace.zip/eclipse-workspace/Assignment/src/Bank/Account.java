package Bank;

public class Account {
double balance;
Account(double initialAmount)
{
	balance=initialAmount;
}
public void withdraw(double amount)
{
	if(amount>0&&balance>=amount)
	{
		balance-=amount;
		System.out.println("Current balance : "+balance);
	}
	else
	{
		System.out.println("Invalid");
	}
}
public void deposite(double amount)
{
	if(amount>0)
	{
		balance+=amount;
		System.out.println("Current balance :"+balance);
	}
	else
		System.out.println("Invalid input");
}
public void checkBalance()
{
	System.out.println("Current balance :"+balance);
}
}
