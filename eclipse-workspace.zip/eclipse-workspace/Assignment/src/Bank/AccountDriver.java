package Bank;
import java.util.*;
public class AccountDriver {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Account a=new Account(5000);
	System.out.println("1.Withdraw\n2.Deposit\n3.CheckBalance");
	System.out.println("Enter the option");
	int option=sc.nextInt();
	switch(option)
	{
	case 1:
		a.withdraw(500);
		break;
	case 2:
		a.deposite(600);
		break;
	case 3:
		a.checkBalance();
		break;
	
	}
}
}
