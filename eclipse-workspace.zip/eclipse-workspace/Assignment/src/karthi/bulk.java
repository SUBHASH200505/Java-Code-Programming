package karthi;

public class bulk {

}
