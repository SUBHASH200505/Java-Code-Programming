package karthi;

public class print_1_to_10 {
public static void main(String[] args) {
	int a=1,n=10;

	
	System.out.println(a);
	
	
}
}
