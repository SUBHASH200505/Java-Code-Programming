package karthi;

class sample implements bulks, jen {
	public void dis() {
		System.out.println("ssd");

	}

	public static void main(String[] args) {
		bulks xs = new sample();
		xs.dis();

	}
}
