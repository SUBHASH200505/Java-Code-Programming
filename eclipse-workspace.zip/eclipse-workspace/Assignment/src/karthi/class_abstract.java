package karthi;

public class class_abstract extends abstr {
	void s()
	{
		System.out.println("ji");
	}
public static void main(String[] args) {
	class_abstract w=new class_abstract();
	w.d();
	w.s();
}
}
class abstr
{
	void d()
	{
		System.out.println("hii");
	}
}
