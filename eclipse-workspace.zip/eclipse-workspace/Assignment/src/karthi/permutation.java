package karthi;

public class permutation {
public static void main(String[] args) {
	String s="abs";
permut(s);
	}
static void permut(String s)
{

	


	
	
	
}

}
