package karthi;

public class abs_cls {
public static void main(String[] args) {
		
		abs_cls s=new abs_cls( );;
		
		
	
	
		
	}
}
 abstract class abs11 extends abs_cls
{
	 void show()
		{
			System.out.println("abs11");
		}

}

