package karthi;

public interface demww {
 public static final int a=93435354;
public static void main(String[] args) {
	
	System.out.println(a);
}
}
