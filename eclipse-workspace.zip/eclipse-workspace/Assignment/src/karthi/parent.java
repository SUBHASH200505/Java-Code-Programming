package karthi;

public class parent {
	
	static void disp()
	{
		System.out.println("hii");
	}
	public static void  main(String[] args) {
		
		parent p=new parent();
		
		p.disp();
		child c=new child();
		c.disp();
		parent p2=new child();
		p2.disp();
		
	}
	
	
}
class child extends parent
{
	static void disp()
	{
		System.out.println("hlo");
	}
}
