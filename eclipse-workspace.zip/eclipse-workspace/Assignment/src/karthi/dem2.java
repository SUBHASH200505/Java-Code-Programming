package karthi;

public class dem2 {
static int a;
void dis()
{  int a=11;
System.out.println(a);
	
}
public static void main(String[] args) {
	new dem2().dis();
	
}
}
