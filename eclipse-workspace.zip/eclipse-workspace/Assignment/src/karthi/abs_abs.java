package karthi;

public class abs_abs  extends abss2{
	public static void main(String[] args) {
		
		abs_abs s=new abs_abs();;
		s.show();
		s.dis();
		
		
	}
}
 abstract class abss1
{
	 void show()
		{
			System.out.println("abss1");
		}

}
 abstract  class abss2 extends abss1
 {
	 void dis()
	 {
		 System.out.println("ass2");
	 }
 }
