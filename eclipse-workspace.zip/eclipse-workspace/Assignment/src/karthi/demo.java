package karthi;
class  demo extends abs
{
	
	
		void show()
		{System.out.println("hiii");
			
		}
		public static void main(String[] args) {
			demo d=new demo();
			d.dis();
			d.show();
		}
		
	
}
 abstract class abs
{
	 void dis()
	 {
	System.out.println("hlo");
	 }
	
}
