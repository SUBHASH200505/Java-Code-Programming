package karthi;

import java.util.Arrays;

public class dem {
 void dis()                                                                                                     
	{
		System.out.println("pp");
	}
 public static void main(String[] args) {
		dem d=new dem();
		ch c=new ch();
		
		dem d2=new ch();
		c.dis();
		d.dis();
		d2.dis();
		
	}
}
class ch extends dem
{
	
	 void dis()
	{
		System.out.println("cc");
	}
	
	
}
