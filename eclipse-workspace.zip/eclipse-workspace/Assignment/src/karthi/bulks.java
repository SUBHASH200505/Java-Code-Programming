package karthi;

public interface bulks {
	int a = 1;

	void dis();

}



interface jen {
	void dis();
}