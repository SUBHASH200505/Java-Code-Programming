package Employee;
import java.util.*;
public class employeedriver {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Employeeutility.display("rock",101,20000,2,"rock@123",1235678);
	
}
}
