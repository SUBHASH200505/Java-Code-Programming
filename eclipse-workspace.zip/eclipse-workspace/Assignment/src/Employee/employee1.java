package Employee;

public class employee1 {
	String name;
	int id;
	double salary;
	int experience=0;
	int phoneno;
	String email;
	{
		experience++;
		System.out.println("Employee created");
	}
employee1(String name,int id,double salary,int experience)
{
	this.name=name;
	this.id=id;
	this.salary=salary;
	this.experience=experience;
}
employee1(int phoneno,String email)
{
	this.phoneno=phoneno;
	this.email=email;
}

}
