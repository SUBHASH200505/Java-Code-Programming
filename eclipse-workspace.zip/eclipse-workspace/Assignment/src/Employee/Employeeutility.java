package Employee;

public class Employeeutility {
public static void display(String name,int id,double salary,int experience,String email,int phoneno)
{
	id++;
	System.out.println(name);
	System.out.println(id);
	System.out.println(salary);
	System.out.println(experience);
	System.out.println(email);
	System.out.println(phoneno);
	System.out.println("Total salary after incremented");
	if(salary>10000&&experience==1)
	{
		System.out.println(salary+1000);
	}
	else if(salary>22000&&experience==2)
	{
		System.out.println(salary+2000);
	}
	if(salary>32000&&experience==3)
	{
		System.out.println(salary+3000);
	}
}
}
