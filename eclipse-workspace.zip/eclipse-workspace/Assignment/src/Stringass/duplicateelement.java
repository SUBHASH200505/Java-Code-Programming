package Stringass;

public class duplicateelement {
public static void main(String[] args) {
	String a="Hello";
	char[] arr=a.toCharArray();
	String result="";
	for(int i=0;i<arr.length;i++)
	{
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i]==arr[j])
			{
				result+=arr[j];
			}
		}
	}
	System.out.println(result);
}
}
