package Stringass;
import java.util.*;
public class Abbrevation {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the input abbrevation");
	String a=sc.nextLine();
	char[] b=a.toCharArray();
	String result="";
	for(int i=0;i<b.length;i++)
	{
		if(b[i]>='A'&&b[i]<='Z')
		{
		result=result+b[i];	
		}
	}
	System.out.println(result);
}
}
