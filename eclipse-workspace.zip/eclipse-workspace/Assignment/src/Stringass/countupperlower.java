package Stringass;

public class countupperlower {
public static void main(String[] args) {
	String a="HellHi";
	char[] arr=a.toCharArray();
	int lower=0;
	int upper=0;
	for(int i=0;i<arr.length;i++)
	{
		if(arr[i]>=97&&arr[i]<=122)
			lower++;
		else if(arr[i]>='A' &&arr[i]<='Z')
		    upper++;
	}
	System.out.println("Total number of lowercase element= "+lower);
	System.out.println("Total number of uppercase element= "+upper);
}
}
