package Stringass;

public class removespace {
public static void main(String[] args) {
	String text = "Hello World";
    String cleanText = text.replaceAll("\\s","");
    System.out.println(cleanText); 
}
}
