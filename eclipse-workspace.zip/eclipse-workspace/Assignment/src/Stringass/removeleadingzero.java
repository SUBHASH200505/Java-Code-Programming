package Stringass;

public class removeleadingzero {
    public static void main(String[] args) {
        String a = "0000000000123456789";
        String result = a.replaceFirst("^0+", "");//replace the 0's with the emptyspace and indicated postive closure
        //^ start 0+ one or more leading zeros
        System.out.println("Without Leading Zeros: "+ result);
    }
}
