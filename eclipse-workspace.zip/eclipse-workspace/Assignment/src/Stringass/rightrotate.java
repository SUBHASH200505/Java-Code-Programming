package Stringass;
import java.util.*;

public class rightrotate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = "Hello world";
        System.out.println("Enter the number of rotations:");
        int a = sc.nextInt();
        sc.close();

        char[] b = str.toCharArray();
        int n = b.length;

        while (a > 0) {
            char last = b[n - 1]; 
               for (int i = n - 1; i > 0; i--) {
                b[i] = b[i - 1];
            }
            b[0] = last; 
            a--;
        }

        System.out.println(Arrays.toString(b)); 
    }
}
