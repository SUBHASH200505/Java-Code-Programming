package Stringass;

public class maxoccurance {
public static void main(String[] args) {
	String str="Hello World";
	char[] a=str.toCharArray();
	int count;
	int ele=0;
	char element=a[0];
	for(int i=0;i<a.length;i++)
	{
		count=1;
		for(int j=i+1;j<a.length;j++)
		{
			if(a[i]==a[j]) {
				count++;
			}
			if(count>ele)
			{
				ele=count;
				element=a[i];
			}
		}
	}
	System.out.println("The letter "+element+" as a maximum occurance "+ele);
}
}
