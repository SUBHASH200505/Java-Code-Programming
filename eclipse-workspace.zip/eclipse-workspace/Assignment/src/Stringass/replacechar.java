package Stringass;
import java.util.*;
public class replacechar {
public static void main(String[] args) {
	String s="Hello world";
	int b=3;
	//String replace="w";
	//System.out.println(s.replace("w", replace));
	char[] a=s.toCharArray();
	for(int i=0;i<a.length;i++)
	{
		if(i==b)
		{
			a[i]='w';
		}
	}
	String v=new String(a);
	System.out.println(a);
}
}
