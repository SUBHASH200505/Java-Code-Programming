package Stringass;

public class duplicatecount {
public static void main(String[] args) {
	String s="Hell";
	int count=0;
	char[] arr=s.toCharArray();
	for(int i=0;i<arr.length;i++)
	{
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i]==arr[j])
			{
				arr[j]=(char)Integer.MIN_VALUE;
				count++;
			}
		}
	}
	System.out.println("Total number of duplicate element= "+count);
}
}
