package Stringass;

import java.util.*;

public class leftrotate {
	public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
    String str = "Hello world";
    System.out.println("Enter the number of rotations:");
    int a = sc.nextInt();
    int length=str.length();

    String result=str.substring(a)+str.substring(0,a);
System.out.println(result);
	}
}
