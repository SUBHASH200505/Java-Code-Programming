package Stringass;

public class maxminoccurance {
public static void main(String[] args) {
	String a="abbbcccc";
	char[] arr=a.toCharArray();
	int count=0;
	char b='a';
	int ele=0;
	for(int i=0;i<arr.length;i++)
	{
		count=1;
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i]==arr[j])
			{
				count++;
				if(ele<count)
				{
				ele=count;
				b=arr[i];
				}
			}
		}
	}
	System.out.println("Max occurance character in the string= "+b);
	min(arr);
			}
public static void min(char[] arr)
{
	int count=0;
	char b='a';
	int ele=0;
	for(int i=0;i<arr.length;i++)
	{
		count=1;
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i]==arr[j])
			{
				count++;
				if(ele>count)
				{
				ele=count;
				b=arr[i];
				}
			}
		}

}
	System.out.println("Minimum occurance char in the string= "+b);
}
}
