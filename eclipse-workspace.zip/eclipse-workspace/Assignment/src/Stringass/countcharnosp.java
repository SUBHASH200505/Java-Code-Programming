package Stringass;

public class countcharnosp {
public static void main(String[] args) {
	String a="Hello12()jj(88";
	char[] arr=a.toCharArray();
	int alp=0;
	int number=0;
	int special=0;
	for(int i=0;i<arr.length;i++)
	{
		if(arr[i]>='a'&&arr[i]<='z'||arr[i]>='A'&&arr[i]<='Z')
		{
			alp++;
		}
		else if(arr[i]>='0'&&arr[i]<='9')
		{
			number++;
		}
		else
			special++;
	}
	System.out.println(alp);
	System.out.println(number);
	System.out.println(special);
}
}
