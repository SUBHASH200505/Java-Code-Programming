package Stringass;

public class evenlengthword {
public static void main(String[] args) {
	String arr="This the new program language";
	String[] a=arr.split(" ");
	String b="";
	for(int i=0;i<a.length;i++)
	{
		if(a[i].length()%2==0)
		{
			b+=a[i]+" ";
		}
	}
	System.out.println(b);
}
}
