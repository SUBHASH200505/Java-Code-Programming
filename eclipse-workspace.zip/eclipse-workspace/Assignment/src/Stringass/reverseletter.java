package Stringass;
public class reverseletter {
    public static void main(String[] args) {
        String arr = "This is the program";
        String[] a = arr.split(" ");  
        String result = "";

        for (int i = 0; i < a.length; i++) {
            for (int j = a[i].length() - 1; j >= 0; j--) { 
                result += a[i].charAt(j);
            }
            result += " ";
        }
        System.out.println(result.trim()); 
    }
}
