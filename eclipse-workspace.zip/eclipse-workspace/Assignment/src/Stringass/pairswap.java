package Stringass;

import java.util.Arrays;

public class pairswap {
public static void main(String[] args) {
	String arr="java";
	char[] a=arr.toCharArray();
	for(int i=0;i<a.length;i+=1)
	{
		for(int j=1;j<a.length;j+=1)
		{
			char temp=a[i];
			a[i]=a[j];
			a[j]=temp;	
		}
	}
	System.out.println(Arrays.toString(a));
}
}
