package Stringass;

public class reemovechar {
public static void main(String[] args) {
	String a="helloworld";
	char e='w';
	String b="";
	for(int i=0;i<a.length();i++)
	{
	char j=a.charAt(i);
	if(j!=e)
	{
		b+=j;
	}
	
	}
	System.out.println(b);
}
}
