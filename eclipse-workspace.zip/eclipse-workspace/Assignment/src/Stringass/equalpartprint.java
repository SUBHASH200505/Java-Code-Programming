package Stringass;
import java.util.*;

public class equalpartprint{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string:");
        String str = sc.nextLine();
        System.out.println("Enter the number of equal parts (N):");
        int N = sc.nextInt();
        sc.close();
        int length = str.length();
        if (length % N != 0) {
            System.out.println("Cannot divide the string into equal parts.");
            return;
        }
        int partSize = length / N; 
        System.out.println("Divided String:");
        for (int i = 0; i < length; i += partSize) {
            System.out.println(str.substring(i, i + partSize));
        }
    }
}
