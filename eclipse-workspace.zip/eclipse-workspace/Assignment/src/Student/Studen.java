package Student;

public class Studen {
		int id;
		String name;
		int age;
		String email;
		long phone;
		static String collegename="Panimalar";
		static int count=0;
		{
			count++;
		}
		static {
			System.out.println("Student Management System");
		}
		Studen(int id,String name,int age){
			this.id=id;
			this.name=name;
			this.age=age;
		}
		Studen(int id,String name,int age,String email,long phone){
			this(id,name,age);
			this.email=email;
			this.phone=phone;
		}
		public static void main(String[] args) {
			StudUtility.marks();
		}
		 {
			System.out.println("Student Object Created");
		}
	}
