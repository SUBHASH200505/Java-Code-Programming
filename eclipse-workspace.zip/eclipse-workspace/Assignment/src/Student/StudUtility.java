package Student;
import java.util.*;
public class StudUtility {
		public static void marks() {
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter id");
			int id=sc.nextInt();
			System.out.println("Enter name");
			String name=sc.next();
			System.out.println("Enter age");
			int age=sc.nextInt();
			Studen s1=new Studen(id,name,age);
			int[] arr=new int[5];
			for(int i=0;i<arr.length;i++)
			    arr[i]=sc.nextInt();
			System.out.println("----Student Details----");
			System.out.println("Student ID: "+s1.id);
			System.out.println("Student Name: "+s1.name);
			System.out.println("Student Age: "+s1.age);
			System.out.println("Email: "+s1.email);
			System.out.println("PhoneNo: "+s1.phone);
			int tot=0;
			int avg=0;
			for(int i=0;i<arr.length;i++)
				tot+=arr[i];
			avg=tot/5;
			System.out.println("Marks: "+Arrays.toString(arr));
		    System.out.println("Total marks: "+tot);
		    System.out.println("Average marks: "+avg);
		
		}

	}

