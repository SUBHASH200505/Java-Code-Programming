package phase2;

public class hello {
static String a="Hello world";
}
