package phase2;

public class String1 {
public static void main(String[] args) {
StringBuffer s1=new StringBuffer("hello");
System.out.println(s1.capacity());
s1=s1.insert(0,"rock");
System.out.println(s1);
System.out.println(s1.delete(0, 1));
System.out.println(s1.substring(0, 4));
}
}
