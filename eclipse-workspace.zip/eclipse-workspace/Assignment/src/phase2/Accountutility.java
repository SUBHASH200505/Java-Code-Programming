package phase2;

public class Accountutility {
public static double calculateSI(double principle,int year,double roi)
{
	return principle*year*roi;
}
}
