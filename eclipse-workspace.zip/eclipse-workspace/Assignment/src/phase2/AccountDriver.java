package phase2;
import java.util.*;
public class AccountDriver {
		public static void main(String[] args) {
			Account a1=new Account(1000);
			Scanner sc=new Scanner(System.in);
			System.out.println("WELCOME TO SBI INDIA");
			System.out.println("\n1.withdraw\n2.deposit\n3.chech balance\n4.pnr");
			System.out.println("enter your choice:");
			int a=sc.nextInt();
			switch(a) {
			case 1:{
				System.out.println("enter the amount:");
				int amount=sc.nextInt();
				a1.withdraw(amount);
				a1.checkbalance();
				break;
			}
			case 2:{
				System.out.println("enter the amount:");
				int amount=sc.nextInt();
				a1.deposit(amount);
				a1.checkbalance();
				break;
			}
			case 3:{
				System.out.println("balance is:");
				a1.checkbalance();
				break;
			}
			case 4:{
				double principle=sc.nextDouble();
				int year=sc.nextInt();
				double rate=sc.nextDouble();
				Accountutility.calculateSI(principle, year, a);
			}
			default:
				System.out.println("INVALID INPUT");
			}
		}
	}

