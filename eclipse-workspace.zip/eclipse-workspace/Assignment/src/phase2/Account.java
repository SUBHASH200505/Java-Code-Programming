package phase2;

public class Account {
		double balance;
		Account(double initialbalance){
			balance=initialbalance;
		}
		public void withdraw(double amount) {
			if(amount>0 &&balance>0) {
					balance-=amount;
					System.out.println("amount withdraw successful");
			}
			else {
				System.out.println("Insufficent ammount or in valid input");
			}
		}
			public void deposit(double amount) {
				if(amount>0) {
						balance+=amount;
						System.out.println("deposit successfully");
				}
				else {
					System.out.println("Insufficent ammount or in valid input");
				}
			}
				public void checkbalance() {
					System.out.println(balance);
					}
	}
