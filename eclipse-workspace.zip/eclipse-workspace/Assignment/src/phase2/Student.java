package phase2;

public class Student {
static int count;
}
