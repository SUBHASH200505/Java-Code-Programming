package phase2;

public class driver {
public static void main(String[] args) {
	hello h1=new hello();
	System.out.println(h1.a);
}
}
