package String1;
import java.util.Arrays;

public class Eliminateduplicate {
    public static void main(String[] args) {
        String s = "PROGRAMMER";
        char[] a = s.toCharArray();
        StringBuffer st = new StringBuffer();

        for (int i = 0; i < a.length; i++) {
            boolean isDuplicate = false;

           
            for (int j = 0; j < st.length(); j++) {
                if (st.charAt(j) == a[i]) {
                    isDuplicate = true;
                    break;
                }
            }

           
            if (!isDuplicate) {
                st.append(a[i]);
            }
        }

  
        System.out.println(st.toString());
    }
}
