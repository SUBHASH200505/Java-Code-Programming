package String1;

public class printfirstduplicate {
	public static void main(String[] args) {
		String s="Heollo";
		char ele='o';
		char[] arr=s.toCharArray();
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]!=(char)Integer.MIN_VALUE)
				continue;
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
				{
					arr[j]=(char)Integer.MIN_VALUE;
					ele=arr[i];
				
					break;
				}
			}

		}
		System.out.println("First duplicate element = "+ele);
		
	}

}
