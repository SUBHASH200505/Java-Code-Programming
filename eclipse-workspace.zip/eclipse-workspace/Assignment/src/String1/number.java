package String1;

import java.util.Arrays;

public class number {
public static void main(String[] args) {
	String s="123";
	int count=0;
	char[] a=s.toCharArray();
	for(int i=0;i<a.length;i++)
	{
		for(char j='0';j<='9';j++)
		{
			if(a[i]==j)
			{
				count++;
			}
		}
	}
	if(count==s.length())
{
	System.out.println("The Array contains only numerical data");
}
	else
	{
		System.out.println("The Array contains mixed data");
	}
}
}
