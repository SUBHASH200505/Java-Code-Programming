package String1;

public class Largestpalindrome {
	public static void main(String[] args) {
		String[] arr= {"MOM","MALAYALAM","RACECAR","MADAM","TAT"};
		String temp=arr[0];
		for(int i=0;i<arr.length;i++)
		{
				if(arr[i].length()>temp.length())
				{
				temp=arr[i];
				}
			}
		System.out.println(temp);
		}
	}

