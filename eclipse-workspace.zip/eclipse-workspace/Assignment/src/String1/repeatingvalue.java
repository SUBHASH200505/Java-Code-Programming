package String1;

public class repeatingvalue {
	public static void main(String[] args) {
        String a = "AABBBCCCC";
        char[] b = a.toCharArray();
        int count;
        char ele='a';
        int max=0;
        for (int i = 0;i < b.length;i++) {
            if (b[i]=='-')  
                continue;
            count = 1;
            for (int j = i + 1;j < b.length;j++) {
                if (b[i] == b[j]) {
                    b[j] = '-'; 
                    count++;
                    if(max<count) {
                    	max=count;
                    	ele=b[i];
                    }
                }
            }
            System.out.print(count+""+b[i]);
    
}
	}
}

