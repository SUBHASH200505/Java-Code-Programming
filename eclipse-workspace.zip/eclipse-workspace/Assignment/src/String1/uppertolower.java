package String1;

public class uppertolower {
public static void main(String[] args) {
	String a="ProGRam";
	String result="";
	for(int i=0;i<a.length();i++)
	{
		char b=a.charAt(i);
		if(b>='a'&&b<='z')
			result+=(char)((int)b-32);
		else if(b>='A'&&b<='Z')
			result+=(char)((int)b+32);
}
	System.out.println(result);
		
}
}
