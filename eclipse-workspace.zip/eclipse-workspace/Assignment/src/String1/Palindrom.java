package String1;

public class Palindrom {
public static void main(String[] args) {
	String s=getInput.get();
	char a;
	char b;
	int count=0;
	int mid=s.length()/2;
	for(int i=0;i<s.length()/2;i++)
	{
		for(int j=s.length()-1;j>mid;j--)
		{
			a=s.charAt(i);
			b=s.charAt(j);
			if(a==b)
			{
				count++;
			}
			
		}
	}
	System.out.println(count);
	
	if(count==mid)
	{
		System.out.println("palindrome");
	}
	else
	{
		System.out.println("Not a palindrome");
	}
}
}
