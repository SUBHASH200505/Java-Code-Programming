package String1;
import java.util.*;
public class getInput {
public static String get() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the String");
	return sc.next();
}
}
