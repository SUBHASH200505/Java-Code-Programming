package String1;
public class frequency {
    public static void main(String[] args) {
        String a = "HELLO";
        char[] b = a.toCharArray();
        int count;
        char ele='a';
        int max=0;
        for (int i = 0;i < b.length;i++) {
            if (b[i]=='-')  
                continue;
            count = 1;
            for (int j = i + 1;j < b.length;j++) {
                if (b[i] == b[j]) {
                    b[j] = '-'; 
                    count++;
                    if(max<count) {
                    	max=count;
                    	ele=b[i];
                    }
                }
            }
            System.out.println(b[i] + " appears " + count + " times");
            
        }
        System.out.println("Max frequency "+ele+" as "+max +" value");
        
    }
}
