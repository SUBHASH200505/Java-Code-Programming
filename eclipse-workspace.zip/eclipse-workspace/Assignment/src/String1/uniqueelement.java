package String1;

public class uniqueelement {
	 public static void main(String[] args) {
	        String a = "HELLO";
	        char[] b = a.toCharArray();
	        int count;
	        for (int i = 0;i < b.length;i++) {
	        	char c=b[i];
	            if (b[i]=='-')  
	                continue;
	            count = 1;
	            for (int j = i + 1;j < b.length;j++) {
	                if (b[i] == b[j]) {
	                    b[j] = '-'; 
	                    count++;
	                }
	               
	            }
	            if(count==1)
		        	System.out.println(c);   
	              
	           
	        }
	        
	        
	    }

}
