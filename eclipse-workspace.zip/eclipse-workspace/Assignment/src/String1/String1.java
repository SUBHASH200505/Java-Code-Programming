package String1;

public class String1 {
public static void main(String[] args) {
	char ab;
	char res;
	String a= "hello";
	for(int i=0;i<a.length();i++)
	{
	ab=a.charAt(i);
	res=(char)(ab-32);
	System.out.print(res);
	}
}
}
