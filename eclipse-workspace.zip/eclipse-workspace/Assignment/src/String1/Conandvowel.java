package String1;
import java.util.*;
public class Conandvowel {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String s=sc.next();
	char a;
	int count=0;
	int count1=0;
	for(int i=0;i<s.length();i++)
	{
		a=s.charAt(i);
		if(a=='a'||a=='e'||a=='i'||a=='o'||a=='u')
		{
			count++;
		}
		else
		{
			count1++;
		}
	}
	System.out.println("Vowels ="+count);
	System.out.println("Consonent ="+count1);
}
}
