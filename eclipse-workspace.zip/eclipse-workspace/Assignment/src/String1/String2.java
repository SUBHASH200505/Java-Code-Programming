package String1;

public class String2 {
public static void main(String[] args) {
	String s="hell";
	for(int i=0;i<s.length();i++)
	{
		System.out.println(s.charAt(i));
	}
}
}
