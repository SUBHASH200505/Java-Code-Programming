package String1;

public class swapvalue {
public static void main(String[] args) {
	String s1="Hello";
	String s2="World";
	
	System.out.println(s1.replace(s1, s2));
	System.out.println(s2.replace(s2,s1));
}
}
