package String1;

import java.util.Arrays;

public class delete {
public static void main(String[] args) {
	String s="HELLO";
	char a='E';
	int pos=0;
	char[] b=s.toCharArray();
	char[] c=new char[b.length];
	for(int i=0;i<b.length;i++)
	{
		if(b[i]!=a)
		{
			c[pos++]=b[i];
		}
	}
	String str=new String(c);
	System.out.print(str);
	
}
}
