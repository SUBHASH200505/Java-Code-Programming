package String1;

import java.util.Arrays;

public class swapstring {
public static void main(String[] args) {
	int start=0;
	String a="ABCD";
	char[] b=a.toCharArray();
	int end=b.length-1;
	char temp=b[start];
	b[start]=b[end];
	b[end]=temp;
	String str = new String(b);
	System.out.println(str);
}
}
