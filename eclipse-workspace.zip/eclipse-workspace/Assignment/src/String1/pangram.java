package String1;

public class pangram {
    public static void main(String[] args) {
        String s = "the quick brown fox jumps over the lazy dog";
        char[] arr = s.toCharArray();
        int count = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] ==0) 
                continue;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    arr[j] = (char) 0; 
                }
            }
            if (arr[i] >= 'a' && arr[i] <= 'z') {
                count++;
            }
        }
        System.out.println(count);
        if(count==26)
        	System.out.println("pangram");
        else
        	System.out.println("Not a pangram");
    }
}
