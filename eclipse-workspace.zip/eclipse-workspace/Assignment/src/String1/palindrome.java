package String1;
import java.util.*;
public class palindrome {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			String s=sc.next();
			pal(s);
			sc.close();
		}
		public static void pal(String s) {
			String b="";
			for(int i=s.length();i>0;i--) {
				b+=s.charAt(i-1);
			}
			if(b.equals(s))
				System.out.println("Palindrome");
			else
				System.out.println("Not palindrome");
			
		}

	}

