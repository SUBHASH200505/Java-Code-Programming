package String1;

public class addingele {
    public static void main(String[] args) {
        String a = "HELLO";
        String b = "WORLD";
        
        char[] e = a.toCharArray();
        char[] d = b.toCharArray();   
        char[] c = new char[a.length() + b.length()]; 
        int pos = 0;      
        for (int i = 0; i < e.length; i++) {
            c[pos++] = e[i];
        }
        for (int i = 0; i < d.length; i++) {
            c[pos++] = d[i];
        }
        String str = new String(c);
        System.out.println(str); 
    }
}
