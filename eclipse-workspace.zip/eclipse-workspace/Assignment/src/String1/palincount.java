package String1;

public class palincount {
		public static void main(String[] args) {
			String[] s= {"malayalam","racecar","top"};
			pal(s);
		}
		public static void pal(String[] s) {
			int count=0;
			String res;
			for(int i=0;i<s.length;i++) {
				String b="";
				res=s[i];
				for(int j=res.length();j>0;j--) {
					b+=res.charAt(j-1);
				}
				if(b.equals(res))
					count++;
			
			}
			System.out.println(count);
			
		}

	}

