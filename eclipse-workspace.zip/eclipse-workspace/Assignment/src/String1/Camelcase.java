package String1;

import java.util.Arrays;

public class Camelcase {
public static void main(String[] args) {
String a="hello world hi";
String[] b=a.split(" ");
System.out.println(Arrays.toString(b));
String result=" ";
for(String s:b)
{
	result+=(char)(s.charAt(0)-32)+s.substring(1)+" ";
}
System.out.println(result);
}
}
