package String1;
import java.util.*;

public class palindorme1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the string");
        String s = sc.next();
        char[] arr = s.toCharArray();
        occurance(s, arr);
        sc.close();
    }

    public static void occurance(String s, char[] arr) {
        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) {  // Changed `j=1` to `j=i+1`
                if (isBoolean(arr[i], arr[j])) {  // Compare `arr[i]` with `arr[j]`
                    System.out.println(arr[i]);
                }
            }
        }
    }

    public static boolean isBoolean(char a, char b) {
        return a != b;  // Simply return the comparison result
    }
}
