package String1;
public class bracket {
    public static void main(String[] args) {
        String s = "(){}{";
        int open = 0;
        char[] a=s.toCharArray();
        for (char ch : a) {
           if(ch=='{')
        	   open++;
           else if(ch=='}')
               open--;
           else if(ch=='(')
        	   open++;
           else if(ch==')')
        	   open--;
            }
        System.out.println(open==0?"Balance":"Not Balanced");
        }
      
    }

