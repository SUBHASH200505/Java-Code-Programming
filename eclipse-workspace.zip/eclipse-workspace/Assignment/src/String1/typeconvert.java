package String1;

import java.util.Arrays;

public class typeconvert {
	public static void main(String[] args) {
		String s1="123";
		char[] arr=s1.toCharArray();
		int sum=0;
		for(int i=0;i<arr.length;i++) {
			if(s1.charAt(0)!='-')
			{
			int b=(int) s1.charAt(i);
					int d=b-48;
					sum=sum*10+d;
			}
			else
			{
				break;
			}
		}System.out.println(sum);
		
	}
}
