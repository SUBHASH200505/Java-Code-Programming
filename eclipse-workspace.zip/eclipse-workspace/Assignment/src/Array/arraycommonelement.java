package Array;

import java.util.Arrays;

public class arraycommonelement {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	int[] arr2= {1,3,5,7};
	int[] result=new int[arr.length];
	int pos=0;
	for(int i=0;i<arr.length;i++)
	{
		for(int j=0;j<arr2.length;j++)
		{
			if(arr[i]==arr2[j])
			{
			  result[pos]=arr[i];
			  pos++;
			  break;
			}
		}
	}
	int[] finalResult = Arrays.copyOf(result, pos);
	System.out.println(Arrays.toString(finalResult));
}
}
