package Array;

import java.util.Arrays;

public class rotatesecondhalf {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8};
        int start = arr.length / 2; 
        int end = arr.length - 1;   


        int last = arr[end];

    
        for (int i = end; i > start; i--) {
            arr[i] = arr[i - 1];
        }

    
        arr[start] = last;

        System.out.println(Arrays.toString(arr));
    }
}
