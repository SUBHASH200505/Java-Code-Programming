package Array;

import java.util.Arrays;

public class combine12 {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5};
	int[] arr1= {6,7,8,9};
	int pos=0;
	int[] result=new int[arr.length+arr1.length];
	for(int i=0;i<result.length;i++)
	{
		if(i<arr.length)
		{
			result[i]=arr[i];
			
		}
		else
		{
			result[i]=arr1[pos];
			pos++;
		}
		
	}
	System.out.println(Arrays.toString(result));
}
}
