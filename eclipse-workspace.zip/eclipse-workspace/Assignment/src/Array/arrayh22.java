package Array;

public class arrayh22 {
	public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	int count=arr.length;
	int sum=0;
	double average=0;
	int half=count/2;
	
	for(int i=half;i<count;i++)
	{
		sum+=arr[i];
	}
	average=sum/half;
	System.out.println(average);
}
}