package Array;

import java.util.Arrays;

public class arraycombine {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5,6};
		int[] arr1= {7,8,9,1};
		int[] result=new int[arr.length+arr1.length];
		int pos=0;
		for(int i=0;i<arr.length;i++)
		{
			result[pos]=arr[i];
			pos++;
		}
		for(int i=0;i<arr1.length;i++)
		{
			result[pos]=arr1[i];
			pos++;
		}
		System.out.println(Arrays.toString(result));
	}

}
