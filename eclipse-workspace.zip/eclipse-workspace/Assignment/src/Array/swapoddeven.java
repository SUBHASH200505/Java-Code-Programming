package Array;

import java.util.Arrays;

public class swapoddeven {
public static void main(String[] args) {
	int[] arr={1,2,3,4,5,6,7};
	int start=0;
while(start<arr.length-1)
	
	{
	int end=start+1;
		int temp=arr[start];
		arr[start]=arr[end];
		arr[end]=temp;
		start=start+2;
		
	}
System.out.print(Arrays.toString(arr));
}
}
