package Array;
import java.util.*;
public class loopingright {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of shift operation");
		int a=sc.nextInt();
	int[] arr= {1,2,3,4,6};
	
	for(int j=0;j<a;j++) { //while(a>0)
		int last=arr[arr.length-1];//index value present inside 
	for(int i=arr.length-1;i>=0;i--)
	{
		if(i!=0)
		arr[i]=arr[i-1];
		if(i==0)
			arr[i]=last;
	}
	}
	for(int i=0;i<arr.length;i++)
		System.out.println(arr[i]);

}
}