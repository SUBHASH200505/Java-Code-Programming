package Array;
import java.util.*;
public class rotateleft {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number of left shift operation");
	int a=sc.nextInt();
	for(int i=0;i<a;i++)
	{
		int last=arr[0];
		for(int j=0;j<arr.length-1;j++)
		{
			arr[j]=arr[j+1];
		}
		arr[arr.length-1]=last;
	}
	System.out.println(Arrays.toString(arr));
}
}
