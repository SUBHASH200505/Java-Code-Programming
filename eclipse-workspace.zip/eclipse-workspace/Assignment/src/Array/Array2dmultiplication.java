package Array;
import java.util.*;

public class Array2dmultiplication {
    public static void main(String[] args) {
        int[][] arr1 = {
            {1, 2, 6}, 
            {6, 9, 7}
        };
        int[][] arr2 = {
            {7, 8}, 
            {34, 12}, 
            {13, 98}
        };

        multiply(arr1, arr2);
    }

    public static void multiply(int[][] arr1, int[][] arr2) {
        int rows = arr1.length;
        int cols = arr2[0].length;
        int[][] res = new int[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                int sum = 0;
                for (int k = 0; k < arr1[0].length; k++) {
                    sum += arr1[i][k] * arr2[k][j];
                }
                res[i][j] = sum;
            }
        }

        System.out.println("Result Matrix:");
        for (int[] row : res) {
            System.out.println(Arrays.toString(row));
        }
    }
}
