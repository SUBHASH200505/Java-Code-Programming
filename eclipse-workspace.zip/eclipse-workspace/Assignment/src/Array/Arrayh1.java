package Array;

public class Arrayh1 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4};
		int sum=arr[0];
		for(int i=1;i<=arr.length-1;i++)
		{
			sum+=arr[i];
		}
		System.out.println(sum);
	}

}
