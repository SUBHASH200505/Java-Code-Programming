package Array;
import java.util.*;
public class test {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int sum=0;
	System.out.println("Enter the array length");
	int a=sc.nextInt();
	int[] arr=new int[a];
	System.out.println("Enter the element one by one");
	for(int i=0;i<arr.length;i++)
	{
		arr[i]=sc.nextInt();
	}
	for(int j=0;j<arr.length;j++)
	{
		if(isprime(arr[j]))
			sum+=arr[j];
	}
	System.out.println(sum);
}
public static boolean isprime(int num)
{
	for(int i=2;i<num;i++)
	{
		if(num%i==0)
		{
			return false;
		}
	}
	return true;
}
}