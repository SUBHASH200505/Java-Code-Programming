package Array;

public class Maxvalue {
public static void main(String[] args) {
	int[] arr= {1,3,5,7};
	int max=Integer.MAX_VALUE;
	for(int i=1;i<arr.length;i++)
	{
		if(arr[0]<arr[i])
			max=arr[i];
	}
	System.out.println(max);
}
}
