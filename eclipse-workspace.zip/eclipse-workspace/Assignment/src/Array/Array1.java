package Array;
public class Array1 {
	public static void main(String[] args) {
		int[] arr= {1,2,3};
		int[] arr1= {1,2,3,4};
		int[] arr2= {1,2,3,4,5};
		for(int a:arr) {
		System.out.print(a);
		}
		System.out.println();
		for(int a:arr1)
			{System.out.print(a);

			
			}
		System.out.println();
		for(int a:arr2)
			{System.out.print(a);

			}
	}

}
