package Array;

public class Array2 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4};
		arr1(arr);
	}
		public static void arr1(int[] arr)
		{
		int sum=0;
		for(int a:arr)
		{
			sum=sum+a;
		}
		int result=sum/arr.length;
		System.out.println("Sum ="+sum);
		System.out.println("Average ="+result);
		
	}

}
