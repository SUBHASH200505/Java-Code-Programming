package Array;
import java.util.*;
public class Array2dprint {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the no of rows");
	int a=sc.nextInt();
	System.out.println("Enter the no of columns");
	int b=sc.nextInt();
	int[][] arr=new int[a][b];
	System.out.println("Enter the rows and columns one by one");
	for(int i=0;i<arr.length;i++)
	{
		for(int j=0;j<arr[i].length;j++)
		{
		arr[i][j]=sc.nextInt();
		}
	}
	System.out.println("2 dimensional array");
	for(int[] c:arr)
	{
		for(int d:c)
		{
			System.out.print(d+" ");
		}
		System.out.println(" ");
	}
}
}
