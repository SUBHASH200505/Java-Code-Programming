package Array;
import java.util.Arrays;

public class Arrayh20 {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 2, 3};
        int count = 0;
        int element = 3;

              for (int num : arr) {
            if (num == element) {
                count++;
            }
        }

                int[] result = new int[arr.length - count];
        int pos = 0;

        
        for (int num : arr) {
            if (num != element) {
                result[pos++] = num;
            }
        }

        // Correctly print the entire array
        System.out.println(Arrays.toString(result));
    }
}
