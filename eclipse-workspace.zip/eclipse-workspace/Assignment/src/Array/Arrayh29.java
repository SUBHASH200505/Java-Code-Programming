package Array;

public class Arrayh29 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5,6};
		int result=0;
		int element=5;
				for(int i=0;i<arr.length-1;i++)
		{
			if(arr[i]==element)
			{
				result=i;
				break;
			}
		}
		if(result!=0)
			System.out.println("Element found in the "+result +" index");
		else
			System.out.println("Element is not found");
	}

}
