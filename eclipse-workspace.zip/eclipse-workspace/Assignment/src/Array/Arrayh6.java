package Array;

public class Arrayh6 {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,7};
	int sum=0;
	for(int i=1;i<arr.length;i+=1)
	{
		sum+=arr[i];
	}
	System.out.println("Sum of odd index = "+sum);
}
}
