package Array;

public class Arrayh21 {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	int count=0;
	int sum=0;
	int average=0;
	for(int i=0;i<arr.length;i++)
	{
		count++;
	}
	for(int i=0;i<count;i++)
	{
		sum+=arr[i];
	}
	average=sum/count-1;
	System.out.println(average);
}

}
