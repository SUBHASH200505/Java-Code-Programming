package Array;

public class oddIndex {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5};
	for(int i=1;i<arr.length-1;i+=2 )
	{
		System.out.println(arr[i]);
	}
}
}
