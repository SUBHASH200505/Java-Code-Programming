package Array;

public class Arrayh4 {
	public static void main(String[] args) {
		int[] arr= {1,3,2,5};
		int sum=0;
		for(int i=0;i<arr.length;i++)
			sum+=arr[i];
		System.out.println("Average value of the array = "+sum/arr.length);
				}

}
