package Array;

public class Arrayh18 {
	public static void main(String[] args) {
		int[] arr= {1,5,3,4,5,6};
		int mid=arr.length/2;
		int start=0;
		int end=mid-1;
		int min=Integer.MAX_VALUE;
		while(start<=end)
		{
			if(arr[start]<min)
		min=arr[start];
		start ++;
		}
		System.out.println("Min value of first half array = "+min);
	}


}
