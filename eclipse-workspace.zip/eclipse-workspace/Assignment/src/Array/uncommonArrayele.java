package Array;

import java.util.Arrays;

public class uncommonArrayele {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7};
        int[] arr1 = {1, 3, 6, 7};
        int[] result = new int[arr.length];
        int pos = 0;

        
        for (int i = 0; i < arr.length; i++) {
            boolean found = false;
            for (int j = 0; j < arr1.length; j++) {
                if (arr[i] == arr1[j]) { 
                    found = true;
                    break; 
                }
            }
            if (!found) { 
                result[pos++] = arr[i];
            }
        }

        
        int[] result1 = Arrays.copyOf(result, pos);
        System.out.println(Arrays.toString(result1));
    }
}
