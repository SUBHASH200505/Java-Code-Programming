package Array;

public class Arrayh24 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5,6};
		int count=arr.length/2;
		for(int i=count-1;i>=0;i--)
		{
			System.out.println(arr[i]);
		}
	}

}
