package Array;
import java.util.*;
public class combinearrayone {
	public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6};
        int[] arr1 = {7, 8, 9, 1, 2};
        
        int maxLength = Math.max(arr.length, arr1.length);
        int[] result = new int[arr.length + arr1.length];

        int index = 0;

        for (int i = 0; i < maxLength; i++) {
            if (i < arr.length) {
                result[index++] = arr[i]; 
            }
            if (i < arr1.length) {
                result[index++] = arr1[i]; 
            }
        }

        System.out.println("Alternating Merged Array: " + Arrays.toString(result));
    }
}