package Array;

import java.util.Arrays;

public class minimumduplicate {
	public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 1, 2, 4};  
        int minDuplicate = Integer.MAX_VALUE; 

        for (int i = 0; i < arr.length; i++) {
            for (int j = i + 1; j < arr.length; j++) { 
                if (arr[i] == arr[j]) { 
                    if (arr[i] < minDuplicate) { 
                        minDuplicate = arr[i];
                    }
                }
            }
        }

        if (minDuplicate == Integer.MAX_VALUE) {
            System.out.println("No duplicates found");
        } else {
            System.out.println("Smallest duplicate: " + minDuplicate);
        }
    }
}
