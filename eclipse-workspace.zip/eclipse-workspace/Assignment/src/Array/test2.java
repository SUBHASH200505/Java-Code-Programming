package Array;
import java.util.*;

public class test2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int count1 = 0; // Corrected unique count initialization
        int a = sc.nextInt();
        int[] arr = new int[a];

        for (int i = 0; i < arr.length; i++) {
            arr[i] = sc.nextInt();
        }

        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == Integer.MIN_VALUE) continue; // Skip already marked elements
            int count = 1;

            for (int j = i + 1; j < arr.length; j++) { // Fix: j starts from i+1
                if (arr[i] == arr[j]) {
                    count++;
                    arr[j] = Integer.MIN_VALUE; // Mark duplicates
                }
            }

            if (count == 1) {
                count1++; // Count unique elements correctly
            }
        }

        System.out.println("Total unique elements = " + count1);

        int pos = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] != Integer.MIN_VALUE) {
                arr[pos++] = arr[i]; 
            }
        }

 
        while (pos < arr.length) {
            arr[pos++] = 0;
        }

        System.out.println(Arrays.toString(arr));
        sc.close();
    }
}
