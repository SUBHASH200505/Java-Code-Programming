package Array;
import java.util.*;
public class Firsthalfreverse {

	 public static void main(String[] args) {


	 Scanner in = new Scanner(System.in);


	 System.out.println("enter the even number");


	 int n = in.nextInt();


	 digit(n);


	 }


	 


	 public static void test(int n, int digit) {


	 int e = digit / 2;


	 int rev = 0;


	 int d = (int) Math.pow(10, e);


	 int l = n / d;


	 int p = n % d;


	 


	 // Reverse the first half


	 while (l > 0) {


	 int a = l % 10;


	 rev = rev * 10 + a;


	 l = l / 10;


	 }


	 // Combine reversed first half with the second half


	 System.out.println(rev * d + p);


	 }


	 


	 public static void digit(int n) {


	 int digit = 0;


	 int d = n;


	 while (n > 0) {


	 n = n / 10;


	 digit++;


	 }


	 test(d, digit);


	 }


	 }



