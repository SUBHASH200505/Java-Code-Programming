dpackage Array;

import java.util.Arrays;

public class findingminmax {
    public static void main(String[] args) {
        int[] arr = {1, 2, 6, 7, 8};
        int min = arr[0];
        int max = arr[0];
        
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] < min)
                min = arr[i];
            if (arr[i] > max)
                max = arr[i];
        }
        
        int[] result = new int[max - min + 1];
        int pos = 0;
        for (int i = min; i <= max; i++) {
            result[pos++] = i;
        }
        
        int[] newres = new int[result.length - arr.length];
        pos = 0;
        for (int i = 0; i < result.length; i++) {
            boolean found = false;
            for (int j = 0; j < arr.length; j++) {
                if (result[i] == arr[j]) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                newres[pos++] = result[i];
            }
        }
        
        System.out.println("Missing Numbers: " + Arrays.toString(newres));
    }
}
