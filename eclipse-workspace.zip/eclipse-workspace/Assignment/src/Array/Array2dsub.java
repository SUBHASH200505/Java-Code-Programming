package Array;
import java.util.*;
public class Array2dsub {

		public static void main(String[] args) {
				int[][] arr1= {{1,2,3},{4,5,6},{7,8,9}};
				int[][] arr2= {{1,2,3},{4,5,6},{7,8,9}};
				int[][] res=calculate(arr1,arr2);
				System.out.println(Arrays.deepToString(res));
		}
				public static int[][] calculate(int[][] arr1,int[][] arr2)
				{
				int res[][]=new int[arr1.length][arr2.length];
				
				for(int i=0;i<arr1.length;i++)
				{
					
					for(int j=0;j<arr1[0].length;j++)
					{
						res[i][j]=arr1[i][j]-arr2[i][j];
					}
				}
				return res;
		
				
						 	}
			}















































