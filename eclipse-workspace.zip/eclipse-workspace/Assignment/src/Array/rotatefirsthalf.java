package Array;

import java.util.Arrays;

public class rotatefirsthalf {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6,7,8};
	int va=arr[arr.length/2-1];
//	for(int i=arr.length/2+1;i>=0;i--)
//	{
//		if(i!=0)
//			arr[i]=arr[i-1];
//		if(i==0) {
//			arr[i]=va;
//		}
//}
	System.out.println("Original Array : "+Arrays.toString(arr));
	int st=0;
	int end=arr.length/2-1;
	
			while(st<end) {
				int temp=arr[st];
				arr[st]=arr[end];
				arr[end]=temp;
				st++;
				end--;
			}
	 System.out.println("Shifted Array : "+Arrays.toString(arr));
}}
