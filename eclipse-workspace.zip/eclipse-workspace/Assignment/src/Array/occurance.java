package Array;

public class occurance {
	public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6,3,4,5,3,4};
	int count;
	for(int i=0;i<arr.length-1;i++)
	{
		if(arr[i]!=Integer.MIN_VALUE) {
		count=1;
		for(int j=i+1;j<arr.length-1;j++)
		{
			if(arr[i]==arr[j])
			{
				arr[j]=Integer.MIN_VALUE;
				count++;
			}
			
		}
		System.out.println("Number of occurance "+ arr[i] +" "+count);
	}
	}
	}
}

