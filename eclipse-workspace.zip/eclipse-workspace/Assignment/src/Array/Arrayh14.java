package Array;

public class Arrayh14 {
	public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	int mid=arr.length/2;
	int start=0;
	int end=mid-1;
	int sum=0;
	while(start<=end)
	{
		sum+=arr[start];
		start++;
	}
	System.out.println("First half sum value of the array"+sum);
}
}
