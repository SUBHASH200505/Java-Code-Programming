package Array;

public class Arrayh7 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5,6};
		int min=Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++)
		{
			if(i%2==0)
			{
				if(arr[i]<min) {
				min=arr[i];
				}
			}
		}
		System.out.println("Minimum value of the even index array = "+min);
	}

}
