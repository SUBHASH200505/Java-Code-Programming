package Array;

public class reverse2 {
public static void main(String[] args) {
	int[] arr= {1,3,2,4};
	for(int i=0;i<arr.length;i++)
	{
		for(int j=arr.length-1;j>=0;j--)
		{
//			if(j>i)
			{
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	for(int arr1:arr)
	{
		System.out.println(arr1);
	}

		
}
}

