package Array;

public class Arrayh17 {
	public static void main(String[] args) {
	int[] arr= {1,2,3,4,23,6};
	int mid=arr.length/2;
	int start=mid;
	int end=arr.length-1;
	int min=Integer.MIN_VALUE;
	while(start<=end)
	{
		if(arr[start]>min)
	min=arr[start];
	start ++;
	}
	System.out.println("Max value of second half array = "+min);
}

}
