package Array;
import java.util.*;
public class Array2dtranspose {
public static void main(String[] args) {
	int[][] arr= {{1,2,3},{4,5,6},{7,8,9}};
	int[][] result=calculate(arr);
	System.out.println(Arrays.deepToString(result));
}
public static int[][] calculate(int[][] arr)
{
	int result[][]=new int[arr[0].length][arr.length];
	for(int i=0;i<arr[0].length;i++)
	{
		for(int j=0;j<arr.length;j++)
		{
			result[j][i]=arr[i][j];
		}
	}
	return result;
}
}
