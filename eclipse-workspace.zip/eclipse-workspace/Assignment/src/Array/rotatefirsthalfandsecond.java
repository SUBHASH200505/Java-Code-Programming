package Array;

import java.util.Arrays;

public class rotatefirsthalfandsecond {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6};

        
        int firsthalf = (arr.length / 2) - 1;
        int first = arr[0]; 
        for (int i = 0; i < firsthalf; i++) {
        	  arr[i] = arr[i + 1];
        }
        arr[firsthalf] = first; 
        
        int end = arr.length - 1;
        int last = arr[end]; 
        for (int j = end; j > arr.length / 2; j--) {
            arr[j] = arr[j - 1]; 
        }
        arr[arr.length / 2] = last;

      
        System.out.println(Arrays.toString(arr));
    }
}
