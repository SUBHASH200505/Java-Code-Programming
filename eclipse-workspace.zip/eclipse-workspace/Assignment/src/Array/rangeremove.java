package Array;
import java.util.*;
public class rangeremove {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int pos=0;
	int[] arr= {1,2,3,4,5,6,7};

	System.out.println("Enter the starting range");
	int a=sc.nextInt();
	System.out.println("Enter the ending range");
	int b=sc.nextInt();
	int[] result=new int[arr.length-(b-a+1)];
	for(int i=0;i<arr.length;i++)
	{
		if(i<a||i>b)
			result[pos++]=arr[i];
	}
	System.out.println(Arrays.toString(result));
		
}
}
