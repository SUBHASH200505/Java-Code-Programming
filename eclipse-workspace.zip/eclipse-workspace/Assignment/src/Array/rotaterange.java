package Array;

import java.util.*;

public class rotaterange {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number of right rotate");
	int a=sc.nextInt();

	for(int r=0;r<a;r++)
	{
		int end=arr[arr.length-1];
	for(int i=arr.length-1;i>0;i--)
	{
		arr[i]=arr[i-1];
	}
	arr[0]=end;
	}
	System.out.println(Arrays.toString(arr));
}
}
