package Array;
import java.util.*;
public class removetheselectindex {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the specified index to remove");
	int a=sc.nextInt();
	

	for(int i=0;i<arr.length;i++)
	{
		if(arr[i]!=arr[a])
		{
			System.out.println(arr[i]);
		}
			
	}
}
}
