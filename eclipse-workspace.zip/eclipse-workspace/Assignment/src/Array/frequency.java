package Array;

import java.util.Arrays;

public class frequency
{
	public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6,3,4,5,3,4};
	int count;
	int[] result=new int[arr.length];
	int pos=0;
	int max=arr[0];
	for(int i=0;i<arr.length-1;i++)
	{
		if(arr[i]!=Integer.MIN_VALUE) {
		count=1;
		for(int j=i+1;j<arr.length-1;j++)
		{
			if(arr[i]==arr[j])
			{
				arr[j]=Integer.MIN_VALUE;
				count++;
			}
			
		}
		System.out.println("Number of occurance "+ arr[i] +" "+count);
		result[pos++]=count;
	}
	}
	System.out.println(Arrays.toString(Arrays.copyOfRange(result,0,pos)));
	for(int i=0;i<result.length;i++)
	{
		if(result[i]>max)
		{
			max=arr[i];
		}
	}
	System.out.println(max);
	}
}

