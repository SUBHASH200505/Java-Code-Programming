package Array;

public class Arrayh16 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,11,5,6};
		int mid=arr.length/2;
		int start=mid;
		int end=arr.length-1;
		int min=Integer.MAX_VALUE;
		while(start<=end)
		{
			if(arr[start]<min)
		min=arr[start];
		start ++;
		}
		System.out.println("Min value of second half array = "+min);
	}

}
