package Array;

import java.util.Arrays;

public class duplicatevalue {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 2, 3};

       
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = i + 1; j < arr.length; j++) { 
                if (arr[i] == arr[j]) {
                    arr[j] = Integer.MIN_VALUE;
                }
            }
        }

        int count = 0;
        for (int a : arr) {
            if (a == Integer.MIN_VALUE) {
                count++;
            }
        }

        result(count, arr);
    }

    public static void result(int count, int[] arr) {
        if (count != 0) {
            int[] result = new int[arr.length - count];
            int pos = 0;
            for (int i : arr) {
                if (i != Integer.MIN_VALUE) {
                    result[pos++] = i;
                }
            }

            
            System.out.println("Array after removing duplicates: " + Arrays.toString(result));
        } else {
            System.out.println("No duplicate element found");
        }
    }
}
