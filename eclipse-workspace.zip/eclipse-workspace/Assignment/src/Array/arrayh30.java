package Array;

public class arrayh30 {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6};
	int i=2;
	int j=4;
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
		System.out.println("Array after swaping");
	for(int k=0;k<arr.length;k++)
	{
		System.out.println(arr[k]);
	}
}
}
