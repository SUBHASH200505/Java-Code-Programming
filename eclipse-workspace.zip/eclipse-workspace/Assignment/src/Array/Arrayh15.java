package Array;

public class Arrayh15 {
	public static void main(String[] args) {
		int[] arr= {1,5,3,4,5,6};
		int mid=arr.length/2;
		int start=0;
		int end=mid-1;
		int max=Integer.MIN_VALUE;
		while(start<=end)
		{
			if(arr[start]>max)
		max=arr[start];
		start ++;
		}
		System.out.println("Max value of first half array = "+max);
	}

}
