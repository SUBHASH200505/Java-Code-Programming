package Array;
import java.util.Arrays;
public class Foundelement {
		public static void main(String[] args) {
			int[] arr= {1,2,20,5,6};
			System.out.println(Arrays.toString(arr));
			int ele=20;
			boolean found=false;
			for(int i=0;i<arr.length;i++) {
				if(arr[i]==ele) {
					found=true;
					break;
				}}
			if(found) {
				int[] res=new int[arr.length-1];
				int pos=0;
				for(int a:arr) {
					if(a!=ele) {
						res[pos]=a;
						pos++;
					}
				}System.out.println(Arrays.toString(res));
			}
			else
				System.out.println("Element not found");
		
	}
	}

