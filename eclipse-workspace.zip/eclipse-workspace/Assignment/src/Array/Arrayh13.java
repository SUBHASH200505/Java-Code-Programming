package Array;

public class Arrayh13 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5,6};
		int mid=arr.length/2;
		int start=mid;
		int sum=0;
		int end=arr.length-1;
		while(start<=end)
		{
			sum+=arr[start];
			start++;
		}
		System.out.println("sum of second half array = "+sum);
}
}