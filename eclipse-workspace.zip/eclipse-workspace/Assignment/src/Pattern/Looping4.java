package Pattern;

public class Looping4 {
public static void main(String[] args) {
	for(int i=0;i<=6;i++)
	{
		for(int j=0;j<=6;j++)
		{
			int res=3;
			if(i==3&&j==3)
			{
				System.out.print("#");
			}
			if(i==j||i+j==6)
			{
				System.out.print("*");
			}
			else
			{
				System.out.print(" ");
			}
		}
		System.out.println(" ");
			
	}
}
}
