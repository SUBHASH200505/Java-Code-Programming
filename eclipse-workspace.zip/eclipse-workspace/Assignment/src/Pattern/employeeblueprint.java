package Pattern;

public class employeeblueprint {
	int id;
	String name;
	double salary;
	employeeblueprint()
	{
	
}
	employeeblueprint(int id)
			{
	this.id=id;
			}
	employeeblueprint(int id,String name)
	{
		this(id);
		this.name=name;
	}
	employeeblueprint(int id,String name,double salary)
	{
		this(id,name);
		this.salary=salary;
	}
	
}
