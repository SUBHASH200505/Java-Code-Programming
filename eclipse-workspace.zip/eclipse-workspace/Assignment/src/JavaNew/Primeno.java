package JavaNew;
import java.util.Scanner;
public class Primeno {
   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the value of N: ");
        int n = sc.nextInt();
        sc.close();
        
        int count = 0;  
        int num = 1;    

        while (count < n) { // Loop until we find N prime numbers
            num++;
            if (isPrime(num)) {
                count++;
            }
        }

        System.out.println("The " + n + "th prime number is: " + num);
    }

    
    public static boolean isPrime(int num) {
        if (num < 2) return false;
        for (int i = 2; i * i <= num; i++) { 
            if (num % i == 0) {
                return false; 
            }
        }
        return true; 
    }
}
