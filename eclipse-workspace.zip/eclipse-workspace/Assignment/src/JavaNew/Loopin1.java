package JavaNew;

public class Loopin1 {

}
