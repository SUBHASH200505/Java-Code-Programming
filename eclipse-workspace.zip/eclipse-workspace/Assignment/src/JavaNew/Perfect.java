package JavaNew;
import java.util.*;
public class Perfect {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number :");
		int a=sc.nextInt();
		for(int i=0;i<a/2;i++)
		{
			if(i*i==a)
			{
				System.out.println("The perfect square of "+a+"is "+i);
			}
		}
	}
}
