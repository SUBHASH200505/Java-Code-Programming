package JavaNew;

public class Firstthree {
    public static void main(String[] args) {
        int count = 0;  // Counter for perfect numbers found
        int num = 1;     // Start checking from 1
        
        System.out.println("First 3 Perfect Numbers:");
        
        while (count < 3) { // Loop until we find 3 perfect numbers
            if (isPerfect(num)) {
                System.out.println(num);
                count++;
            }
            num++;  // Check next number
        }
    }

    // Function to check if a number is perfect
    public static boolean isPerfect(int num) {
        int sum = 0;

        // Find divisors and sum them
        for (int i = 1; i <= num / 2; i++) {
            if (num % i == 0) {
                sum += i;
            }
        }

        return sum == num; // A perfect number has sum of divisors equal to itself
    }
}
