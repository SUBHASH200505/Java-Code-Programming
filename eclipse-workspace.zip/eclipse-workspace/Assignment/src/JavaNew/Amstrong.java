package JavaNew;
import java.util.*;

public class Amstrong {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number ");
        int a = sc.nextInt();
        int original = a; 
        int count = 0;

        while (a != 0) {
            a = a / 10;
            count++;
        }

        double n = power(count, original); 

        if (original == n) {
            System.out.println(original + " is an Armstrong number");
        } else {
            System.out.println(original + " is not an Armstrong number");
        }

        sc.close();
    }

    public static double power(int count, int a) {
        double sum = 0;

        while (a != 0) {
            int digit = a % 10;
            sum += Math.pow(digit, count);
            a = a / 10;
        }

        return sum;
    }
}
