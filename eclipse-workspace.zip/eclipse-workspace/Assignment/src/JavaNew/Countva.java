package JavaNew;
import java.util.*;
public class Countva {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number ");
		int a=sc.nextInt();
		int count=0;
		int result;
		while(a!=0)
		{
			a=a/10;
			count++;
		}
		if(count!=0)
		{
			System.out.println("The no of digit of the given number "+count);
		}
		else 
		{
			System.out.println("Enter the valid number");
		}
	}

}
