package JavaNew;
import java.util.*;
public class sample {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	calculate(a);
}
public static void calculate(int a)
{
	int temp=a;
	int sum=0;
	int mult=1;
	while(temp>0)
	{
		temp%=10;
		for(int i=1;i<=temp;i++)
		{
			mult*=i;
			sum+=mult;
		}
		temp/=10;
		System.out.println(sum);
		
	}
}
}
 