package JavaNew;
import java.util.*;
public class Multiplyf {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the starting number");
	int a=sc.nextInt();
	System.out.println("Enter the ending number");
	int b=sc.nextInt();
	display(a,b);
}
public static void display(int a,int b)
{
	int mult=1;
	for(int i=a;i<=b;i++)
	{
		mult=mult*i;
		System.out.println(i);
	}
	System.out.println(mult);
}
}
