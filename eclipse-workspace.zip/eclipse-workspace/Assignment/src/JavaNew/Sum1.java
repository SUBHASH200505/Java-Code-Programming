package JavaNew;
import java.util.Scanner;
public class Sum1 {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter a number:");
	        int num = sc.nextInt();
	        sumOfFactors(num);
	        
	        sc.close(); 
	    }

	    public static void sumOfFactors(int num) {
	        int sum = 0;
	        int mult=1;
	        for (int i = 1; i <= num; i++) {
	            if (num % i == 0) {
	                sum += i;
	                mult*=i;
	            }
	        }
	        System.out.println(sum);
	        System.out.println(mult);
	    }
	}
