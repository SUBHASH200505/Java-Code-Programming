package JavaNew;
import java.util.*;

public class Divisible {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the starting number:");
        int a = sc.nextInt();
        System.out.println("Enter the ending number:");
        int b = sc.nextInt();
        
        display(a, b);
        sc.close();
    }

    public static void display(int a, int b) {
        int mult = 1;
        boolean found = false;

        for (int i = a; i <= b; i++) {
      
            if (i % 3 == 0 && i % 5 == 0) {
                mult *= i;
                found = true;
            }
        }

        if (found) {
            System.out.println("Final product of numbers divisible by 3 and 5: " + mult);
        } else {
            System.out.println("No numbers found that are divisible by both 3 and 5 in the given range.");
        }
    }
}
