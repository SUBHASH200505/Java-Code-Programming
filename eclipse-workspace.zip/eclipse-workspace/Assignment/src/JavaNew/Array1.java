package JavaNew;
import java.util.*;
public class Array1 {
	public static void main(String[] args) {
		int[] arr= {1,2,3,4,5};
		System.out.println(arr.length);
		
		for(int i:arr)
		{
			System.out.println(i);
		}
	}

}
