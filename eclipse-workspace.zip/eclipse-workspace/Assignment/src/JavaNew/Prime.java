package JavaNew;
import java.util.Scanner;

public class Prime {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        // Take input from user
        System.out.println("Enter the starting number:");
        int a = sc.nextInt();
        System.out.println("Enter the ending number:");
        int b = sc.nextInt();
        
        System.out.println("Prime numbers in the given range:");
        
        // Loop through the range
        for (int i = a; i <= b; i++) {
            if (isPrime(i)) {  // Check if the number is prime
                System.out.println(i);
            }
        }
        
        sc.close();
    }

    public static boolean isPrime(int num) {
        if (num < 2) {
            return false; 
        }
        for (int i = 2; i <= num / 2; i++) {           
        	if (num % i == 0) {
                return false; 
            }
        }
        return true;
    }
}
