package Advance;
import java.util.*;
public class StringDamon {
public static void main(String[] args) {
		String name="2034";
		int total=0;
		int[] arr=new int[name.length()];
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=name.charAt(i)-'0';
			total+=arr[i];
		}
		Arrays.sort(arr);
		
		int step=0;
		int damon=0;
		for(int i=arr.length-1;i>=0;i--)
		{
			step+=arr[i];
			damon=total-step;
		if(step>damon)
		{
			System.out.println(step);
			return;
		}
		}
		
			
}
}
