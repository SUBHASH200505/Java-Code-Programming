package stream;
import java.util.stream.*;
import java.util.*;
public class even {
public static void main(String[] args) {
	List<Integer> list=Arrays.asList(10,15,20,25,30);
	List<Integer> str=list.stream().filter(a->a%2==0).collect(Collectors.toList());
	System.out.println(str);
	
	
}
}
