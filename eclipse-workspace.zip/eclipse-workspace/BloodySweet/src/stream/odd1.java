package stream;
import java.util.*;
import java.util.stream.Collectors;
public class odd1 {
	public static void main(String[] args) {
		List<Integer> str=Arrays.asList(12,20,15,22,17,19);
		List<Integer> arr=str.stream().filter(a->a%2!=0).collect(Collectors.toList());
		System.out.println(arr);
	}

}
