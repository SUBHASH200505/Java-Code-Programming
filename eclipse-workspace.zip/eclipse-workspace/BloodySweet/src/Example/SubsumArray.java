package Example;
import java.util.*;
public class SubsumArray {
public static void main(String[] args) {
	int[] arr= {1,4,3,2,6,4};
	int max=0;
	for(int i=0;i<arr.length;i++)
	{
		if(i+2<arr.length)
		{
		if((arr[i]+arr[i+2])==arr[i+1])
			max++;
		}
	}
	System.out.println(max);
	
}
}
