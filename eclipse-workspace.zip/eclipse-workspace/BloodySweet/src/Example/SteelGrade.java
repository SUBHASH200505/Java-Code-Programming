package Example;
import java.util.Scanner;

public class SteelGrade {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking input values
        System.out.print("Enter the hardness of the steel: ");
        double hardness = sc.nextDouble();

        System.out.print("Enter the carbon content of the steel: ");
        double carbonContent = sc.nextDouble();

        System.out.print("Enter the tensile strength of the steel: ");
        int tensileStrength = sc.nextInt();

        int grade = 5; // 
        boolean condition1 = hardness > 50;
        boolean condition2 = carbonContent < 0.7;
        boolean condition3 = tensileStrength > 5600;

        if (condition1 && condition2 && condition3) {
            grade = 10;
        } else if (condition1 && condition2) {
            grade = 9;
        } else if (condition2 && condition3) {
            grade = 8;
        } else if (condition1 && condition3) {
            grade = 7;
        } else if (condition1 || condition2 || condition3) {
            grade = 6;
        }

        // Output the steel grade
        System.out.println("The grade of the steel is: " + grade);

        sc.close(); // Closing scanner
    }
}
