package Example;
import java.util.Scanner;
public class Vowels {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character");
		char a=sc.next().charAt(0);
		vowel(a);
	}
	public static void vowel(char a)
	{
		switch(a)
		{
		case 'a','e','i','o','u':
			System.out.println(a+" Vowels");
		    break;
		default:
			System.out.println(a+" Consonants");
			break;
		}
	}

}
