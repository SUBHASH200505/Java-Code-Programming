package Example;
import java.util.*;
public class School {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of student");
		int a=sc.nextInt();
		System.out.println("Enter the number of candies");
		int b=sc.nextInt();
		System.out.println("Each student have "+ candies(a,b) +"candies");
		System.out.println("Remaining chocolate="+candies1(a,b));
		sc.close();
	}
	public static int candies(int a,int b)
	{
		int sc=b/a;
		return sc;
	}
	public static int candies1(int a,int b)
	{
		int sr=b%a;
		return sr;
	}
}
