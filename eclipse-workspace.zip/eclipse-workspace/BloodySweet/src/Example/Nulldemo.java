import java.util.*;
/*class Nulldemo {
    public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the username");
		String username=sc.next();
		System.out.println("Enter the password");
		String password=sc.next();
		String username1="Rocky";
		String password1="1234567";
		String result=(username==username1)&&(password==password1)?"Login successfully":"Invalid username and password";
		System.out.println(result);

    }
}
 //number is divisible by 3 and 5 
 class Nulldemo
 {
	 public static void main(String[] args)
	 {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the number");
		 int number=sc.nextInt();
		 String result=(number%3==0)&&(number%5==0)?"Number is divisible by 3 and 5":"Number is not divisible by 3 and 5";
		 System.out.println(result);
	 }

 }
 //either the number is divisible by 5 or 3
 class Nulldemo
 {
	 public static void main(String[] args)
	 {
		 int number=10;
		 String result=(number%3==0)||(number%5==0)?"Number is divisible by 3 and 5":"Number is not divisible by 3 and 5";
		 System.out.println(result);
	 }
 }
 class Nulldemo
 {
	 public static void main(String[] args)
	 {
		 int a=10,b=20;
		 char ch='a';
		 int res=(a++ + ch++ + a-- + ++b +(ch*2));
		 System.out.println(res);
	 }
 } 
 class Nulldemo
 {
	 public static void main(String[] args)
	 {
		 int balance=1000;
  		 int transfer=500;
		 balance -=transfer;
		 int deposit =1500;
		 balance +=deposit;
		 int transfer1=700;
		 balance -=transfer1;
		 System.out.println("available balance= "+balance);
	 }

 }
 class Nulldemo
 {
	 public static void main(String[] args)
	 {
		 int a=10;
		 int b=80;
		 int c=30;
		 int d=40;
		 int result=a>b && a>c && a>d ? a : b>c && b>d ? b : c>d ? c: d;
		 System.out.println(result);

	 }
 }*/
 class Nulldemo
 {
	 public static void main(String[] args)
	 {
		 byte a=97;
		 char b=a;
		 System.out.println(b);
	 }
 }
