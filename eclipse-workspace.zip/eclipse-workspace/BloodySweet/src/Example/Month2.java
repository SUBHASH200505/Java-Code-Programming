package Example;
import java.util.Scanner;
public class Month2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the month = ");
		String a=sc.next();
		month(a);
	}
	public static void month(String a)
	{
		if(a.equals("December")||a.equals("January")||a.equals("February"))
			System.out.println("Winter");
		else if(a.equals("March")||a.equals("April")||a.equals("May"))
			System.out.println("Spring");
		else if(a.equals("June")||a.equals("July")||a.equals("August"))
			System.out.println("Summer");
		else if(a.equals("September")||a.equals("October")||a.equals("November"))
			System.out.println("Autumn");
		else
			System.out.println("Invalid input");
	}

}
