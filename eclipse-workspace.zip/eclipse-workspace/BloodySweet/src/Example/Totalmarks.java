package Example;
import java.util.*;

public class Totalmarks {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int tam, eng, sci, soc, math;
        
        System.out.print("Enter the Tamil mark: ");
        tam = sc.nextInt();
        System.out.print("Enter the English mark: ");
        eng = sc.nextInt();
        System.out.print("Enter the Science mark: ");
        sci = sc.nextInt();
        System.out.print("Enter the Social Science mark: ");
        soc = sc.nextInt();
        System.out.print("Enter the Math mark: ");
        math = sc.nextInt();
        
        sc.close(); 
        
        int totalMarks = total(tam, eng, sci, soc, math);
        double average = avg(totalMarks);
        
        System.out.println("Total Marks: " + totalMarks);
        System.out.println("Average Marks: " + average);
    }

    public static int total(int tam, int eng, int sci, int soc, int math) {
        return tam + eng + sci + soc + math;
    }

    public static double avg(int total) {
        return (double) total / 5;
    }
}
