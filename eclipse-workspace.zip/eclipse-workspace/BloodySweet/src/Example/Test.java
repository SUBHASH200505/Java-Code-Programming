package Example;
import java.util.*;
public class Test {
    public static void main(String[] args)
    {
        System.out.println("Hello world");
        display();
        show();
    }
    public static void display()
    {
    	System.out.println("Welcome !");
    }
    public static void show()
    {
    	System.out.println("The peccc college");
    }
}