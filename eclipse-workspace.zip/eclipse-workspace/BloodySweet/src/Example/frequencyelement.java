package Example;

public class frequencyelement {
    public static void main(String[] args) {
        String a = "abcdabcabc";
        char[] arr = a.toCharArray();
        String value = "";
        int count;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i]!=0)
            {
            count = 1;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                    arr[j] = 0;
                }
            }
            value += arr[i] + String.valueOf(count);  
        }
        }
        System.out.println(value);  
    }
}
