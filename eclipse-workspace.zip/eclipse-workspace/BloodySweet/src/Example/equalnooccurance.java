package Example;

public class equalnooccurance {
    public static void main(String[] args) {
        String input = "aabb";
        char[] arr = input.toCharArray();
        boolean[] visited = new boolean[arr.length];
        int max = -1;  // this will hold the count of the first unique character

        for (int i = 0; i < arr.length; i++) {
            if (visited[i]) continue; // skip if already counted

            int count = 1;
            visited[i] = true;

            for (int j = i + 1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                    visited[j] = true;
                }
            }

            if (max == -1) {
                max = count;  // store count of first unique character
            } else {
                if (count != max) {
                    System.out.println("false");
                    return;  // exit early if mismatch found
                }
            }
        }

        System.out.println("true"); // all characters matched max count
    }
}
