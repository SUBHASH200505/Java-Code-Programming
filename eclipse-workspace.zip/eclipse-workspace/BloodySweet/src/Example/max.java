package Example;

public class max {
	public static void main(String[] args) {
		calmax.m(56, 87);
		calmax.m(45, 50,56,74);
		calmax.m(78,98,44);
	}


}
