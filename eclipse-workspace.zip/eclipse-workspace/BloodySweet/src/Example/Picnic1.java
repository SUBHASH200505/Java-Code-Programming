package Example;

import java.util.Scanner;

public class Picnic1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking input for temperature
        System.out.print("Enter the temperature (in °C): ");
        int temperature = sc.nextInt();

        // Taking input for weather condition
        System.out.print("Enter the weather (warm/cold): ");
        String weather = sc.next().toLowerCase(); // Convert input to lowercase for consistency

        // Checking conditions
        if (temperature > 20 && weather.equals("warm")) {
            System.out.println("Go to picnic");
        } else {
            System.out.println("Don't go to picnic");
        }

        sc.close(); // Closing scanner
    }
}
