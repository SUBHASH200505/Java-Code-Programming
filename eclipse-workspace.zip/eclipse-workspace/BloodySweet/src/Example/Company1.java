package Example;

public class Company1 {
    public static void main(String[] args) {
        int salary = 60000;
        System.out.println("Employee bonus = " + bonus(salary));
    }

    public static String bonus(int salary) {
        String res = salary > 50000 ? "10 % bonus" : "5 % bonus";
        System.out.println("Total salary = " + calculation(salary, res));
        return res;
    }

    public static double calculation(int salary, String res) {
        double result = res.equals("10 % bonus") ? (salary * 0.1)+salary : (salary * 0.05)+salary;
        return result;
    }
}
