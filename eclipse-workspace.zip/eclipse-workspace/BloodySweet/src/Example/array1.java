import java.util.*;
class array1 {
    public static void main(String[] args) {
        int[] arr={1,2,3};
		int[] arr1={4,5,6};
		int[] arr2={7,8,9};
		int result=(arr[2]+arr1[1]+arr[0]);
		System.out.println(result);
}
}