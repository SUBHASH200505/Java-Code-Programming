package Example;
import java.util.*;
public class Demo2 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the 1st number =");
		int a=sc.nextInt();
		System.out.println("Enter the 2nd number =");
		int b=sc.nextInt();
		Demo2 d1=new Demo2();
		System.out.println("Addition ="+d1.addition(a, b));
		System.out.println("subraction ="+d1.subraction(a, b));
		System.out.println("multiplication ="+d1.multiplication(a, b));
		System.out.println("division ="+d1.division(a, b));
		System.out.println("modulus ="+d1.modulus(a, b));
			}
	public int addition(int a,int b)
	{
		int c=a+b;
		return c;
	}
	public int subraction(int a,int b)
	{
		int c=a-b;
		return c;
	}
	public int multiplication(int a,int b)
	{
		int c=a*b;
		return c;
	}
	public double division(int a,int b)
	{
		int c=a/b;
		return c;
	}
	public int modulus(int a,int b)
	{
		int c=a%b;
		return c;
	}
}
