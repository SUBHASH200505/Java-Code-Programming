package Example;
import java.util.*;
public class Welcome {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char s;
		do {
			System.out.println("Welcome");
			System.out.println("Do you want to print again(y/n) :");
			 s=sc.next().charAt(0);
			}
		     
		while(s=='y'||s=='Y');
		}
	}

