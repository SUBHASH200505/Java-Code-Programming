package Example;
import java.util.*;

public class Alphabet {
    public static void main(String[] args) {
        char ch='*';
        
        String result = (ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122) ? "Alphabet" :
                        (ch >= 48 && ch <= 57) ? "Number" :
                        "Special character";
        System.out.println(result);
    }
}
