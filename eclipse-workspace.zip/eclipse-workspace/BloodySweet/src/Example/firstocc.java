package Example;

public class firstocc {
public static void main(String[] args) {
	String s1="hhwelloworhelrloldhelhellol";
	String s2="hell";
   for(int i=0;i<s1.length()-s2.length();i++)
   {
	   String value=s1.substring(i,i+s2.length());
	   if(value.equals(s2))
		   System.out.println(i);
	   else
		   System.out.println(-1);
   }
}
}
