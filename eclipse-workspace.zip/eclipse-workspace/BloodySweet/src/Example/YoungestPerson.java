package Example;
import java.util.Scanner;

public class YoungestPerson {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.print("Enter the age of A: ");
        int ageA = sc.nextInt();
        
        System.out.print("Enter the age of B: ");
        int ageB = sc.nextInt();
        
        System.out.print("Enter the age of C: ");
        int ageC = sc.nextInt();

            if (ageA < ageB && ageA < ageC) {
            System.out.println("A is the youngest.");
        } else if (ageB < ageA && ageB < ageC) {
            System.out.println("B is the youngest.");
        } else if (ageC < ageA && ageC < ageB) {
            System.out.println("C is the youngest.");
        } else {
            System.out.println("There is a tie in age.");
        }

        sc.close(); 
    }
}

