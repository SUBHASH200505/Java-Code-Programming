package Example;

public class countword {
	public static void main(String[] args)
	{
	String name="Hi Hello World";
	String[] arr=name.trim().split("\\s+");
	System.out.println(arr.length);	
	}
}
