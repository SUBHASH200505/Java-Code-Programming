package Example;
import java.util.*;
public class Factor {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number =");
		int a=sc.nextInt();
		factor(a);
	}
	public static void factor(int a)
	{
		int count=0;
		System.out.println("Factors= ");
		for(int i=1;i<=a;i++)
		{
			if(a%i==0)
			{
				System.out.println(i);
				count+=1;
			}
		}
			System.out.println("Total number of count"+count);
			if(count==2)
			{
				System.out.println("Prime number");
			}
			else
			{
				System.out.println("Not a prime number");
			}
	}

}
