package Example;

public class example2 {
	public static void main(String[] args)
	{
		method();
	    ascii.asciivalue('b');
	}
	public static void method()
	{
		System.out.println("Hello world");
	}

}
