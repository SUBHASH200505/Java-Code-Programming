package Example;

public class Example1 {
    public static void main(String[] arg) {
        System.out.println("Enough battery continue the mission: " + battery(60));
        System.out.println("Lower power mode: " + power("Lower power mode"));
        String re=power("Lower power mode")==false?"Start the mission":"Abort the mission";
        System.out.println(re);
    }

    public static String battery(int a) {
        return a > 50 ? "Enough battery" : "Plug the charger";
    }

    public static boolean power(String mode) {
       boolean roc=mode=="Lower power mode"?true:false;
        return roc;
    }
}
