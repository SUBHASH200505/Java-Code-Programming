package Example;

public class Maximum1 {
	public static void main(String[] args)
	{
		System.out.println("Finding maximum off numbers");
		System.out.println(max(10,20));
		System.out.println(max(10,20,30));
	}
	public static int max(int a,int b)
	{
		int str=a<b?b:a;
		return str;
	}
	public static int max(int a,int b,int c)
	{
		int d=a>b&&a>c?a:b<c?c:b;
		return d;
	}

}
