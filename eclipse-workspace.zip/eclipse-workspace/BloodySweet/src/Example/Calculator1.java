package Example;
import Example.Calculator2;
import java.util.*;
public class Calculator1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number 1");
		int a=sc.nextInt();
		System.out.println("Enter the number 2");
		int b=sc.nextInt();
		System.out.println("Enter the operation(+,-,*,/,%) =");
		char choice=sc.next().charAt(0);
		switch(choice)
		{
		case '+':
			System.out.println(Calculator2.add(a,b));
			break;
		case '-':
			System.out.println(Calculator2.sub(a,b));
			break;
		case '*':
			System.out.println(Calculator2.mul(a,b));
			break;
		case '/':
			System.out.println(Calculator2.div(a,b));
			break;
		case '%':
			System.out.println(Calculator2.modulo(a,b));
			break;
		default:
			System.out.println("Invalid input");
		}
}
}