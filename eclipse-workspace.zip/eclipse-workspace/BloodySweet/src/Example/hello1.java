package Example;
import java.lang.reflect.Method;

public class hello1 {
	    public static void main(String[] args) {
	        Method[] methods = Math.class.getDeclaredMethods();

	        System.out.println("Methods in Math class:");
	        for (Method method : methods) {
	            System.out.println(method.getName());
	        }
	    }
}
