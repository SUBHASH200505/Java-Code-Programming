package Example;
import java.util.*;
public class BusCompany {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the age = ");
	int a=sc.nextInt();
	bus(a);
}
public static void bus(int a)
{
	if(a<12)
		System.out.println("$10");
	else if(a>=12&&a<60)
		System.out.println("$20");
	else if(a>60)
		System.out.println("$15");
	else 
		System.out.println("invalid age");
}
}
