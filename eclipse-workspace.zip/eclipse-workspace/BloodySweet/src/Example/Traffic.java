package Example;
import java.util.*;
public class Traffic {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the speed limit");
		int a=sc.nextInt();
		System.out.println("Traveling speed");
		int b=sc.nextInt();
		System.out.println("Speed of the vehicle ="+speed(a,b));
	}
	public static String speed(int a,int b)
	{
		String str=a>b?"correct speed !":"overspeed ride slow !";
		return str;
	}

}

