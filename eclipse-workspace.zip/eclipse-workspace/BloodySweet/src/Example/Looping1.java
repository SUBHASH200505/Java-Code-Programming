package Example;
import java.util.*;
public class Looping1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the starting limit");
		int a=sc.nextInt();
		System.out.println("Enter the ending limit");
		int b=sc.nextInt();
		System.out.println("\nEven numbers\n");
		int add=0;
		int mult=1;
		for(int i=a;i<=b;i++)
		{
			if(i%2==0)
			{
				add=add+i;
				mult=mult*i;
			
			}
		}
			System.out.println("Addition="+add);
			System.out.println("Multiplication="+mult);
		System.out.println("\nOdd numbers\n");
		for(int i=a;i<=b;i++)
		{
			if(i%2==1)
			System.out.println(i);
		}
	}

}
