class Pincode
{   
	public static void main(String[] args)
	{
	int pin=600067;
	System.out.println("pincode = "+pin);
	}
}