package Example;
import java.util.Scanner;

public class Amount1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the amount:");
        int a = sc.nextInt();
        money(a);
    }

    public static void money(int a) {
        int count;

        count = a / 500;
        System.out.println("500 : " + count);
        a %= 500; 
        count = a / 100;
        System.out.println("100 : " + count);
        a %= 100;
        count = a / 50;
        System.out.println("50 : " + count);
        a %= 50;
        count = a / 10;
        System.out.println("10 : " + count);
        a %= 10;
        count = a / 2;
        System.out.println("2 : " + count);
        a %= 2;
        if (a > 0) {
            System.out.println("Remaining amount" + a);
        }
    }
}
