package Example;
import java.util.*;
public class GrossSalary {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the basic salary =");
		int a=sc.nextInt();
		System.out.println("Enter the total experience =");
		int b=sc.nextInt();
	}
	public static void salary(int a,int b)
	{
		double res=0;
		if(a<=10000)
		{
			 res=0.20*0.80*a;
			System.out.println("Basic salary= "+(result+a));
		}
		else if(a<=20000)
		{
			 res=0.25*0.90*a;
			System.out.println("Basic salary= "+(result+a));
		}
		else 
		{
			 res=0.30*0.95*a;
			System.out.println("Basic salary= "+(result+a));
		}
	}
}
}
