package Example;
import java.util.*;
public class Salary1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the salary =");
		int a=sc.nextInt();
		calculation(a);
	}
	public static void calculation(int a)
	{
		if(a<1500)
		{
			double hra=0.10*a;
			double da=0.90*a;
			System.out.println("Gross salary ="+(hra+da+a));
		}
		else
		{
			int hra=500*a;
			double da=0.98*a;
			System.out.println("Gross salary ="+(hra+da+a));
		}
	}

}
