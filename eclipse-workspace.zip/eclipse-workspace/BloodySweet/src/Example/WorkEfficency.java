package Example;

import java.util.Scanner;

public class WorkEfficency {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking input for time required to complete the job
        System.out.print("Enter the time taken by the worker (in hours): ");
        double time = sc.nextDouble();

        // Checking conditions and determining efficiency
        if (time >= 2 && time < 3) {
            System.out.println("Worker is highly efficient.");
        } else if (time >= 3 && time < 4) {
            System.out.println("Worker is ordered to improve speed.");
        } else if (time >= 4 && time < 5) {
            System.out.println("Worker is given training to improve speed.");
        } else if (time >= 5) {
            System.out.println("Worker has to leave the company.");
        } else {
            System.out.println("Invalid input! Time cannot be less than 2 hours.");
        }

        sc.close(); // Closing scanner
    }
}
