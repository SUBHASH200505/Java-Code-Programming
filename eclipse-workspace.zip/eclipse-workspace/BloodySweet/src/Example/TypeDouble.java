package Example;

public class TypeDouble {
		public static void main(String[] args)
		{
			double re=10.5;
			double result=(int)re;
			System.out.println(result);
		}
}
