package Example;

import java.util.Scanner;

public class Validate1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking input for length and breadth
        System.out.print("Enter the length of the rectangle: ");
        int length = sc.nextInt();

        System.out.print("Enter the breadth of the rectangle: ");
        int breadth = sc.nextInt();

        // Calculating area and perimeter
        int area = length * breadth;
        int perimeter = 2 * (length + breadth);

        // Checking condition
        if (area > perimeter) {
            System.out.println("The area of the rectangle is greater than its perimeter.");
        } else {
            System.out.println("The area of the rectangle is NOT greater than its perimeter.");
        }

        sc.close(); // Closing scanner
    }
}

