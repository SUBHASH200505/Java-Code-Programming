package Example;

public class AmountTransfer  {
    public static void main(String[] args) {
        int balance = 1000;
        System.out.println("Balance = " + balance);

        balance = balance - 500;
        System.out.println("After transfer! Balance = " + balance);

		balance = balance + 1500;
        System.out.println("After deposit! Balance = " + balance);

        balance = balance - 200;
        System.out.println("After deposit! Balance = " + balance);

        balance = balance - 700;
        System.out.println("After transfer! Balance = " + balance);

        System.out.println("Total Balance = " + balance);
    }
}
