package Example;

import java.util.Scanner;

public class recursion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        printing(a);
    }
    public static void printing(int b) {
        if (b == 0) {
            return;
        }
        System.out.println(b);
        printing(b - 1);
    }
}
