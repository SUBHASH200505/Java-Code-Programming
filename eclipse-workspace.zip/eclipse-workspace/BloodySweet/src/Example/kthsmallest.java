package Example;

import java.util.Arrays;

public class kthsmallest {
	public static void main(String[] args)
	{
	int[] arr= {2,3,4,1,8};
	int k=3;
	Arrays.sort(arr);
	System.out.println(arr[k]);
	}
	
}
