package Example;

public class stringduplic {
    public static void main(String[] args) {
        String name = "abcbcdda";
        char[] str = name.toCharArray();
        int minDistance = Integer.MAX_VALUE;
        char result = '0';
        for (int i = 0; i < str.length; i++) {
            for (int j = i + 1; j < str.length; j++) {
                if (str[i] == str[j]) {
                    int distance = j - i - 1;
                    if (distance < minDistance) {
                        minDistance = distance;
                        result = str[i];
                    }
                    break;
                }
            }
        }

        System.out.println("First twice letter with minimum distance: " + result);
    }
}
