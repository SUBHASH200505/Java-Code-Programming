package Example;

public class PrintingS {
    public static void main(String[] args) {
        System.out.println(print(10));
        System.out.println(print(10.11));
        System.out.println(print(true));
        System.out.println(print("Hello"));
        System.out.println(print('c'));
    }

    public static int print(int a) {
        return a; 
    }

    public static double print(double d) {
        return d; 
    }

    public static boolean print(boolean b) {
        return b; 
    }

    public static String print(String s) {
        return s; 
    }

    public static char print(char c) {
        return c; // Returning the actual value
    }
}
