package Example;

public class calmax {
public static void m(int a,int b)
{
	System.out.println(Math.max(a, b));
}
public static void m(int a,int b,int c)
{
	int l=Math.max(a, b);
	
	System.out.println(Math.max(l,c));
}
public static void m(int a,int b,int c,int d)
{
		int r=Math.max(a, b);
		int m=Math.max(c, d);
	System.out.println(Math.max(r,m));
}

}
