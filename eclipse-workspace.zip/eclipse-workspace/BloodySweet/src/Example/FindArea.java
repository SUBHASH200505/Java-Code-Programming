package Example;

public class FindArea {
	    public static void area(int radius) {
	        double result = Math.PI * radius * radius;
	        System.out.println("Area of Circle: " + result);
	    }
	    
	    public static void area(int length, int breadth) {
	        int result = length * breadth;
	        System.out.println("Area of Rectangle: " + result);
	    }
	    
	    public static void area(byte side) {
	        int result = side * side;
	        System.out.println("Area of Square: " + result);
	    }
	    public static void main(String[] args)
	    {
	    	area(566);
	    	area(10,20);
	    	area(55);
	    }
	}

