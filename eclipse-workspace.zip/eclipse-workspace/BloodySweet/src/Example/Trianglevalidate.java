package Example;

import java.util.Scanner;

public class Trianglevalidate {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Taking input for three angles
        System.out.print("Enter the first angle: ");
        int angle1 = sc.nextInt();

        System.out.print("Enter the second angle: ");
        int angle2 = sc.nextInt();

        System.out.print("Enter the third angle: ");
        int angle3 = sc.nextInt();

        // Checking if the sum of angles is 180 degrees
        if (angle1 + angle2 + angle3 == 180) {
            System.out.println("The triangle is valid.");
        } else {
            System.out.println("The triangle is NOT valid.");
        }

        sc.close(); // Closing scanner
    }
}
