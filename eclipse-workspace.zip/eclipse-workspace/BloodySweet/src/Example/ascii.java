package Example;

public class ascii {
public static void main(String[] args) {
	asciivalue('a');
	asciivalue('b');
	asciivalue('c');
}
public static void asciivalue(char a)
{
	System.out.println((int)a);
}
}
