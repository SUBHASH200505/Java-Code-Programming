package Example;
import java.util.*;
public class Eletricity {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of units");
		double a=sc.nextInt();
		bill(a);
	}
	public static void bill(double a)
	{
		double b=1.50*a;
		if(a<=50)
		{
			System.out.println("Total eletricity bill ="+(0.50*a));
		}
		else if(a>=51&&a<=150)
		{
			System.out.println("Total eletricity bill ="+(0.75*a));
		}
		else if(a>=151&&a<=250)
		{
			System.out.println("Total eletricity bill ="+(1.20*a));
		}
		else
		{
			System.out.println("Total eletricity bill ="+b);
			System.out.println("Additional charge include the bill ="+(((b/5)+b)-b));
		}
	}

}
