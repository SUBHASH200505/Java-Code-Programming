package Example;
import java.util.*;

public class Marks2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter the physics mark: ");
        int a = sc.nextInt();
        
        System.out.print("Enter the chemistry mark: ");
        int b = sc.nextInt();
        
        System.out.print("Enter the biology mark: ");
        int c = sc.nextInt();
        
        System.out.print("Enter the maths mark: ");
        int d = sc.nextInt();
        
        System.out.print("Enter the computer mark: ");
        int e = sc.nextInt();
        
        int totalMarks = total(a, b, c, d, e);
        int averageMarks = avg(a, b, c, d, e);
        
        System.out.println("Total marks = " + totalMarks);
        System.out.println("Average marks = " + averageMarks);
        
        // Grade Calculation
        calculate(averageMarks);
        
        sc.close();  // Close the scanner to prevent resource leaks
    }

    public static int total(int a, int b, int c, int d, int e) {
        return a + b + c + d + e;
    }

    public static int avg(int a, int b, int c, int d, int e) {
        return (a + b + c + d + e) / 5;
    }

    public static void calculate(int avg) {
        if (avg >= 90) {
            System.out.println("Grade A");
        } else if (avg >= 80) {
            System.out.println("Grade B");
        } else if (avg >= 70) {
            System.out.println("Grade C");
        } else if (avg >= 60) {
            System.out.println("Grade D");
        } else if (avg >= 40) {
            System.out.println("Grade E");
        } else {
            System.out.println("Grade F");
        }
    }
}
