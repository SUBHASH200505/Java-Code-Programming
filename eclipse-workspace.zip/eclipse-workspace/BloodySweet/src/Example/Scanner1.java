package Example;
import java.util.*;
public class Scanner1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("mention the review for the java class");
		String f=sc.nextLine();
		
		System.out.println("Enter the age =");
		int a=sc.nextInt();
		
		System.out.println("Enter the cgpa");
		double b=sc.nextDouble();
		System.out.println("Enter the section");
		char c=sc.next().charAt(0);
		System.out.println("Enter your name =");
		String d=sc.next();
		System.out.println("Enter the marrtial status =");
		String e=sc.next();
		System.out.println("Details \n"+a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		
	}
}
