package Example;

import java.util.Scanner;

public class Widthdraw {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int accountBalance = 5000; // Example initial balance
        
        // Taking input for withdrawal amount
        System.out.print("Enter the amount to withdraw (Multiples of ₹100): ");
        int withdrawAmount = sc.nextInt();

        // Checking conditions
        if (withdrawAmount % 100 != 0) {
            System.out.println("Error: Amount must be in multiples of ₹100.");
        } else if (withdrawAmount > accountBalance) {
            System.out.println("Error: Insufficient balance.");
        } else {
            accountBalance -= withdrawAmount; // Deducting amount
            System.out.println("Transaction Successful!");
            System.out.println("Remaining Balance: ₹" + accountBalance);
        }

        sc.close(); // Closing scanner
    }
}

