import java.util.*;

class Shapess{
    int result;

    // Method to calculate area
    public void area(int len, int bre) {
        result = len * bre;
        System.out.println("The total area = " + result);
    }
}

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // Corrected semicolon
        int len = sc.nextInt(); // Input for length
        int bre = sc.nextInt(); // Input for breadth
        
        Shapess re = new Shapess(); // Creating an object of Rectangle
        re.area(len, bre); // Calling the area method with user inputs
    }
}
