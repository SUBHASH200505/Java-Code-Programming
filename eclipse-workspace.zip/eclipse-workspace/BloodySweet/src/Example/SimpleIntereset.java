package Example;

public class SimpleIntereset {
	public static void main(String[] args)
	{
		display(10000,3,8);
	}
	public static void display(long a,int b,int c)
	{
		double ch=(a*b*c)/100;
		System.out.println(ch);
	}

}
