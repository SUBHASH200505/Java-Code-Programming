package Example;

public class Details {
    public static void main(String[] args) {
        int age = 20;
        char section = 'C';
        float cgpa = 8.99f;
        String name = "Subhash";
        String maritalStatus = "unmarried";

        System.out.println("Age: " + age + "\nSection: " + section + "\nCGPA: " + cgpa + "\nName: " + name + "\nMarital Status: " + maritalStatus);
    }
}