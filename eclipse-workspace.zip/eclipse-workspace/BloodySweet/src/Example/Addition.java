package Example;

public class Addition {
public static void main(String[] args) {
	String arr="hello";
	for(int i=arr.length()-1;i>=0;i--)
	System.out.print(arr.charAt(i));
}
}
