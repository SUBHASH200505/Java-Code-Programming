package Example;
import java.util.*;
public class Bitwiseop {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		System.out.println(voting(age));
	}
		public static void voting(int age)
		{
		if(age<18)
		{
			System.out.println("Your are eligible for voting");
		}
		else
		{
			System.out.println("Your are not eligible for voting");
		}
	}

}
