package Example;
import java.util.*;
public class Power {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the base number");
		int a=sc.nextInt();
		System.out.println("Enter the power value");
		int b=sc.nextInt();
		power(a,b);
		
	}
	public static void power(int a,int b)
	{
		int result=1;
		for(int i=1;i<=b;i++)
		{
			 result=result*a;
		}
		System.out.print(result);
	}

}
