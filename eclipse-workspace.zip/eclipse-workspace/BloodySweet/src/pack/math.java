package pack;


public class math {
	public static void main(String[] args) {
		int a=30;
	
		
		double res=Math. cos(a);
		System.out.println(res);
	}

}
