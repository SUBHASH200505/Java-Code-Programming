package pack;

public class printer {
void print(Demo d)
{
	d.test(10);
}

Demo get()
{
	return (a)->System.out.println(a);
}
}
