package pack;

class Node {
    int data;    
    Node left;     
    Node right;      

    Node(int data) {
        this.data = data;
        left = right = null;
    }
}

class BinarySearchTree {
    Node root;  
    public void add(int data) {
        root = addRecursive(root, data);
    }

    private Node addRecursive(Node currentnode, int data) {
        if (currentnode == null) {
            return new Node(data);  
        }

        if (data < currentnode.data) {
            currentnode.left = addRecursive(currentnode.left, data);
        } else if (data > currentnode.data) {
            currentnode.right = addRecursive(currentnode.right, data); 
        }

        return currentnode;
    }


    public boolean contains(int data) {
        return containsRecursive(root, data);
    }

    private boolean containsRecursive(Node current, int data) {
        if (current == null) return false;
        if (data== current.data) return true;

        return data< current.data
            ? containsRecursive(current.left, data)
            : containsRecursive(current.right, data);
    }

    public void inOrder() {
        inOrderRecursive(root);
        System.out.println();
    }

    private void inOrderRecursive(Node node) {
        if (node != null) {
            inOrderRecursive(node.left);    
            System.out.print(node.data + " ");
            inOrderRecursive(node.right);   
        }
    }
}
