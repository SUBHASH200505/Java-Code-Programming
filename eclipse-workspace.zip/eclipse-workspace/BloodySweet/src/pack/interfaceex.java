package pack;

public class interfaceex {

}
