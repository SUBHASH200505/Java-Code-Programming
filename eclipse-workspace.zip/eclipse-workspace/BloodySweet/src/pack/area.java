package pack;

public class area {
	public static void main(String[] args) {
		circle.a(7);
		circle.a(7,9);
		circle.a(5.6,5.8);
	}

}
