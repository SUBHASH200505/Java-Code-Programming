package pack;

public class assign {
public static void main(String[] args) {
	print(10);
	print(true);
	print("hello");
	print(56.22);
	print('a');
}
public static void print(int a)
{
	System.out.println(a);
}
public static void print(boolean b)
{
	System.out.println(b);
}
public static void print(String c)
{
	System.out.println(c);
}
public static void print(double d)
{
	System.out.println(d);
}
public  static void print(char a)
{
	System.out.println(a);
}




}


