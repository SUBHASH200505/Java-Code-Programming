package pack;
import java.util.Scanner;

public class review {
public static void main(String[] args)
{
	Scanner sc =new Scanner(System.in);
	
	System.out.println("hello");
	int age=sc.nextInt();
	double cgpa=sc.nextDouble();
	sc.nextLine();
	String name=sc.nextLine();
	boolean marital_status =sc.nextBoolean();
	String java_class_review=sc.nextLine();
	
	System.out.println(age);
	System.out.println(cgpa); 
	System.out.println(name);
	System.out.println(marital_status);
	System.out.println(java_class_review);
	
}
}
