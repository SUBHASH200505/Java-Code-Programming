package pack;

public class circle {


	public static void a(double r,double pi)
{
	System.out.println(r*r*pi);
}
public static void a(int l,int b)
{
	System.out.println(l*b);
}
public static void a(int s)
{
	System.out.println(s*s);
	
}
}

