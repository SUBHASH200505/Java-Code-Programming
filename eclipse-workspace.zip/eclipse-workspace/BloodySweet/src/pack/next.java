package pack;
import java.util.Scanner;

public class next {
public static void main(String[] args)
{
	Scanner sc =new Scanner(System.in);
	
	System.out.println("hello");
	String name=sc.next();
	sc.nextLine();
	String java_class_review=sc.nextLine();
	System.out.println(name);
	System.out.println(java_class_review);
}
}
