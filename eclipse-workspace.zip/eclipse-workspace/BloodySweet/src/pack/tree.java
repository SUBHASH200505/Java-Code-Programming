package pack;

import java.util.TreeSet;

public class tree {
public static void main(String[] args) {
	TreeSet<Integer> i=new TreeSet<>();
	i.add(10);
	i.add(20);
	i.add(30);
	i.add(40);
	i.add(1);
	System.out.println(i.descendingIterator());
}
}
