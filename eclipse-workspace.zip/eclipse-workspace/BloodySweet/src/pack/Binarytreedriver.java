package pack;

public class Binarytreedriver {
	    public static void main(String[] args) {
	    	BinarySearchTree bst = new BinarySearchTree();

	  
	        bst.add(50);
	        bst.add(30);
	        bst.add(70);
	        bst.add(20);
	        bst.add(40);

	        System.out.print("In-order: ");
	        bst.inOrder();  
	        
	    }
	}
