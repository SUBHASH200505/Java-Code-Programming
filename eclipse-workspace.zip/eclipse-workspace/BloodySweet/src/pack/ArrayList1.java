package pack;
import java.util.*;
public class ArrayList1 {
public static void main(String[] args) {
	ArrayList<Integer> str=new ArrayList<Integer>();
	str.add(20);
	str.add(10);
	str.add(3);
	str.add(60);
	str.add(5);
	ArrayList<Integer> str1=new ArrayList<Integer>();
	for(int i:str)
	{
		if(i%2==0)
			str1.add(i);
	}
	System.out.println(str1
			);
} 
}
