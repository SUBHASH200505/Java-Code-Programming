import java.util.*;
public class Reversen {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the even digit number");
		int n=sc.nextInt();
		int a=n;
		int count=0;

		while(a!=0)
		{
			a=a/10;
			count++;
		}
		if(count%2==0)
		{
		System.out.println("Even digit number="+n);
		int temp=n%100;
		int mult=temp%10;
		int result=temp/10;
		int rc=mult*10+result;
		System.out.println(rc);
		display(n,rc);
		
		}
		}
public static void display(int a,int rc)
{
	int result=a/100;
	System.out.println(result);
	int output=(result*100)+rc;
	System.out.println(output);
}
	}


