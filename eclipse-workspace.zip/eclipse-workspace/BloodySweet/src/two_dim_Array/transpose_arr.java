package two_dim_Array;

public class transpose_arr {
public static void main(String[] args) {
	int[][] arr1= {{1,2,0},{8,9,0}};
	transpose( arr1);
	
			
}
static void transpose(int[][] arr1)
{int[][] res=new int[arr1[0].length][arr1.length];
	for(int i=0;i<arr1[0].length;i++)
	{
		for(int j=0;j<arr1.length;j++)
			res[i][j]=arr1[j][i];
	}
	for(int[] a:res)
	{
		for(int val:a) {
			System.out.print(val+" ");	
		}
		System.out.println();
	}
	
}
}
