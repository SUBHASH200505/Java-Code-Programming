package two_dim_Array;

public class sum_2d_arr {
public static void main(String[] args) {
	int[][] arr1= {{1,2,6},{6,9,7}};
	int[][] arr2= {{7,8,34},{12,13,98}};
	int res[][]=new int[arr1.length][arr1[0].length];
	
	for(int i=0;i<arr1.length;i++)
	{
		
		for(int j=0;j<arr1[0].length;j++)
		{
			res[i][j]=arr1[i][j]+arr2[i][j];
		}
	}
	for(int[] a:res)
	{
		for(int c:a)
		{
		System.out.print(c+" ");		 	
	}
		System.out.println();
	}
	
	
			 
}
}
