package two_dim_Array;

public class rev_digit {

	public static void main(String[] args) {
		int n=123456;
		int s=0;
		
		while(n>0)
		{
		int c=	n%10;
			s+=n*10;
			n/=10;
		}
		
		System.out.println(s);
	}

}
