package two_dim_Array;
import java.util.Arrays;
public class multiply_2_array {
public static void main(String[] args) {
	int[][] arr1= {{1,2,6},{6,9,7}};
	int[][] arr2= {{7,8,34},{12,13,98}};
	
	multiply( arr1, arr2);
	
}
public static void multiply(int[][] arr1,int[][] arr2)
{int res[][]=new int[arr1.length][arr1[0].length];

for(int i=0;i<arr1.length;i++)
{
	for(int j=0;j<arr2[0].length;j++)
	{
		for(int k=0;k<arr1[0].length;k++)
		{
			res[i][j]+=arr1[i][k]*arr2[k][j];
			
		}
		
		
	}
	
}
System.out.println(Arrays.deepToString(res));
System.out.println(res);
}

}
