package Arraysquestions;
import java.util.*;
public class Arraysumtrue {
public static void main(String[] args) {
	int[] arr= {2,-1,7};
	int sum=16;
	int result=0;
	for(int i=0;i<arr.length;i++)
	{
		for(int j=i;j<arr.length;j++)
		{
			result+=arr[j];
			if(result==sum)
			{
				System.out.println("true");
				return;
			}
		}
		result=0;
	}
}
}
