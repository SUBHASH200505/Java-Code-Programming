package Arraysquestions;
import java.util.*;

public class LeaderSum {
    public static void main(String[] args) {
        List<Integer> arr = Arrays.asList(16, 17, 4, 3, 5, 2);
        ArrayList<Integer> leaders = new ArrayList<>();
        int leader = arr.get(arr.size() - 1);
        leaders.add(leader);
        for (int i = arr.size() - 2; i >= 0; i--) {
            if (arr.get(i) > leader) {
                leader = arr.get(i);
                leaders.add(leader);
            }
        }
        Collections.reverse(leaders);
        for(int a:leaders)
        	System.out.print(a+" ");
    }
}
