package Arraysquestions;
import java.util.*;
public class TwoRepeatingElement {
public static void main(String[] args) {
	int[] arr= {2,4,2,1,5,1,1};
	for(int i=0;i<arr.length;i++)
	{
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i]==arr[j]&&arr[i]!=Integer.MIN_VALUE)
			{
				System.out.print(arr[i]+" ");
				arr[j]=Integer.MIN_VALUE;
				break;
			}
		}
	}
}
}
