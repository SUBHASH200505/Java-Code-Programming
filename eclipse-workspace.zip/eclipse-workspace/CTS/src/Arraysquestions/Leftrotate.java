package Arraysquestions;
import java.util.*;
public class Leftrotate {
public static void main(String[] args) {
	int[] arr= {1,2,3,4,5,6,7};
	Scanner sc=new Scanner(System.in);
	int a=sc.nextInt();
	while(a!=0)
	{
		int first=arr[0];
	for(int i=0;i<arr.length-1;i++)
	{
		arr[i]=arr[i+1];
	}
	arr[arr.length-1]=first;
	a--;
	}
	System.out.println(Arrays.toString(arr));
}
}
