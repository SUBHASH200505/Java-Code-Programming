package Arraysquestions;
import java.util.*;
public class MultiplicationArray {
public static void main(String[] args) {
	int[] arr= {1,2,3,4};
	int[] arr1=new int[arr.length];
	int result=1;
	for(int i=0;i<arr.length;i++)
	{
		result=1;
		for(int j=0;j<arr.length;j++)
		{
			if(i!=j)
			{
			result*=arr[j];
			}
			arr1[i]=result;
		}
	}
	System.out.println(Arrays.toString(arr1));
}
}
