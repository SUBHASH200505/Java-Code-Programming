package Arraysquestions;

public class RemoveMiniElement {
    public static void main(String[] args) {
        int[] arr = {4, 5, 100, 9, 10, 11, 12, 15, 200};
        int n = arr.length;
        int count = 0;

        for (int start = 0; start < n; start++) {
            for (int end = n - 1; end >= start; end--) {
                int min = Integer.MAX_VALUE;
                int max = Integer.MIN_VALUE;
                for (int k = start; k <= end; k++) {
                    min = Math.min(min, arr[k]);
                    max = Math.max(max, arr[k]);
                }

                if (2 * min > max) {
                    count++; 
                }
            }
        }

        System.out.println("Number of valid subarrays where 2 * min > max = " + count);
    }
}
