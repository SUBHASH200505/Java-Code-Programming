package Arraysquestions;public class ArraySort {
    public static void main(String[] args) {
        int[] arr = {1,2,3,4,5,6,7,8};
        String result = "";
        int k = 3;
        for (int i = 0; i < arr.length; i++) {
            result += String.valueOf(arr[i]);
            }
        String enter = "";
        for (int i = 0; i < result.length(); i += k) {
            int end = Math.min(i + k, result.length());
            StringBuffer strChunk = new StringBuffer(result.substring(i, end));
            enter += strChunk.reverse();
           }
        System.out.println(enter);
        char[] arr1=enter.toCharArray();
        for(int i=0;i<arr1.length;i++)
        {
        	System.out.print(arr1[i]+" ");
        }
    }
}
