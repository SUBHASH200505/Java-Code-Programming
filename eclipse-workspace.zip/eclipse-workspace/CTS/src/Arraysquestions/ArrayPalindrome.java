package Arraysquestions;
import java.util.*;
public class ArrayPalindrome {
public static void main(String[] args) {
	int[] arr= {111,1231,222};
	boolean palindrom=true;
	int count=1;
	for(int i=0;i<arr.length;i++)
	{
		String result=String.valueOf(arr[i]);
		String result1 = new StringBuilder(result).reverse().toString();
		if(!result.equals(result1))
		{
		    palindrom=false;
		    break;
		}
	}
	if(palindrom)
		System.out.println("ValidPalindrome array");
	else
		System.out.println("Not valid palindrome");
	
}
}
