package Arraysquestions;
import java.util.*;
public class ArraySortW {
public static void main(String[] args) {
	int[] arr= {10,20,30,40};
	int[] arr1= {15,25,35,45};
	int[] newarr=new int[arr.length+arr1.length];
	int i=0,j=0,k=0;
	while(i<arr.length&&j<arr1.length)
	{
		if(arr[i]<arr1[j])
		{
			newarr[k]=arr[i];
			k++;
			i++;
		}
		else
		{
			newarr[k]=arr1[j];
			k++;
			j++;
		    
		}
	}
	while(i<arr.length)
	{
		newarr[k]=arr[i];
		i++;
		k++;
	}
	while(j<arr.length)
	{
		newarr[k]=arr1[j];
		j++;
		k++;
	}
	System.out.println(Arrays.toString(newarr));
}
}
