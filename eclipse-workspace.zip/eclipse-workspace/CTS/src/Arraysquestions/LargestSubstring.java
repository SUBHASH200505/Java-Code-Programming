package Arraysquestions;
import java.util.*;
public class LargestSubstring {
public static void main(String[] args) {
	String name="abbacbbbbbb";
	String result1="";
	for(int i=0;i<name.length();i++)
	{
		for(int j=i+1;j<=name.length();j++)
		{
			String result=name.substring(i,j);
			if(result.length()<=1)
			{
				continue;
			}
			String name1=new StringBuffer(result).reverse().toString();
			if(result.equals(name1)&&result.length()>result1.length())
			{
				result1=result;
			}
			
		}
	}
	System.out.println(result1);
}
}
