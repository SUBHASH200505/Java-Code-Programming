package Stringquestions;
import java.util.*;

public class Sumdigit {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.next();  

        int sum = 0;
        String num = "";

        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            if (Character.isDigit(ch)) {
                num += ch;  
            } else {
                if (!num.isEmpty()) {
                    sum += Integer.parseInt(num);  
                    num = "";  
                }
            }
        }

        if (!num.isEmpty()) {
            sum += Integer.parseInt(num);
        }

        System.out.println("Sum of numbers: " + sum);
    }
}
