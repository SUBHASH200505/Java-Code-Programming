package Stringquestions;
import java.util.Scanner;

public class ZeroBetweenOnes {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        for (int i = 0; i < name.length(); i++) {
            if (name.charAt(i) == '1') {
                for (int j = i + 1; j < name.length(); j++) {
                    if (name.charAt(j) == '1') {
                        for (int k = i + 1; k < j; k++) {
                            if (name.charAt(k) == '0') {
                                System.out.println("not valid");
                                return;
                            }
                        }
                        System.out.println("valid");
                        return; 
                    }
                }
            }
        }
        System.out.println("No pair of 1s found");
    }
}
