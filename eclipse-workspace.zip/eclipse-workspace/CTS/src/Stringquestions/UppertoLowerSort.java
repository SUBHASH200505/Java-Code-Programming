package Stringquestions;
import java.util.*;
public class UppertoLowerSort {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	char[] arr=name.toCharArray();
	for(int i=0;i<name.length();i++)
	{
		if(Character.isUpperCase(arr[i]))
		{
			arr[i]=Character.toLowerCase(arr[i]);
		}
		else
		{
			arr[i]=Character.toUpperCase(arr[i]);
		}
	}
	Arrays.sort(arr);
    Arrays.toString(arr);
    System.out.println(new String(arr));
	
}
}
