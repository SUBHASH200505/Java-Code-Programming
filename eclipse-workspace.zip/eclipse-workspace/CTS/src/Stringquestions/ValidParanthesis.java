package Stringquestions;
import java.util.*;

public class ValidParanthesis {
    public static void main(String[] args) {
        String s = "(()))";
        Stack<Character> stack = new Stack<>();
        int count = 0;
        for (char ch : s.toCharArray()) {
            if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                if (!stack.isEmpty()) {
                    stack.pop(); 
                    count++;      
                }
            }
        }
        System.out.println("Total valid length: " + (count * 2));
    }
}
