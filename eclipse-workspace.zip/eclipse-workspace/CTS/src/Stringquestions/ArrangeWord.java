package Stringquestions;
import java.util.*;

public class ArrangeWord {
    public static void main(String[] args) {
        String str = "is2 sentence4 this1 a3";
        String[] arr = str.split(" ");
        String[] result = new String[arr.length];
        String value="";
        for (String word : arr) {
            int position = word.charAt(word.length() - 1) -49;
            result[position] = word.substring(0, word.length() - 1);
        }
        for(int i=0;i<arr.length;i++)
        {
        	value+=result[i]+" ";
        }

        System.out.println(value);
    }
}
