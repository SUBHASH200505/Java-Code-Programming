package Stringquestions;
import java.util.*;
public class MostFreqWord {
public static void main(String[] args) {
	String[] arr= {"hello","hi","world","hello","hello"};
	int count=0;
	int max=0;
	String result="";
	for(int i=0;i<arr.length;i++)
	{
		count=0;
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i].equals(arr[j]))
			{
				count++;
			}
		}
		if(count>max)
		{
			max=count;
			result=arr[i];
		}
	}
	System.out.println(result+max);
}
}
