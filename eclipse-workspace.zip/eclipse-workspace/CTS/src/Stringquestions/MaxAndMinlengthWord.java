package Stringquestions;
import java.util.*;

public class MaxAndMinlengthWord {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String name = sc.nextLine();

        String[] arr = name.split(" ");
        String minWord = arr[0];
        String maxWord = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i].length() > maxWord.length()) {
                maxWord = arr[i];
            }
            if (arr[i].length() < minWord.length()) {
                minWord = arr[i];
            }
        }

        System.out.println("Maximum word length in the string = " + maxWord);
        System.out.println("Minimum word length in the string = " + minWord);
    }
}
