package Stringquestions;
import java.util.*;
public class StringReverse {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	String result="";
	/*for(int i=name.length()-1;i>=0;i--)
	{
		result+=name.charAt(i);
	}
	System.out.println(result);*/
	StringBuilder str=new StringBuilder(name);
	result=str.reverse().toString();
	System.out.println(result);
}

}
