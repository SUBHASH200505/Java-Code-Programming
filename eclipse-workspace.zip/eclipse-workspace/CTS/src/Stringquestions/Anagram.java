package Stringquestions;
import java.util.*;
public class Anagram {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	String name1=sc.next();
	char[] arr=name.toLowerCase().toCharArray();
	char[] arr1=name1.toLowerCase().toCharArray();
	if(arr.length!=arr1.length)
		System.out.println("Not a Anagram");
	else
	{
		Arrays.sort(arr);
		Arrays.sort(arr1);
	}
 if(Arrays.equals(arr,arr1))
 {
	 System.out.println("Anagram");
 }
 else
	 System.out.println("Not Anagram");
 
}
}
