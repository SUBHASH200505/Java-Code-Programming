package Stringquestions;
import java.util.*;
public class MaxOccuracnechar {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	char[] arr=name.toCharArray();
	int max=0;
	char result='1';
	for(int i=0;i<arr.length;i++)
	{
		int count=1;
		for(int j=i+1;j<arr.length;j++)
		{
			if(arr[i]==arr[j]&&arr[i]!='0')
			{
				count++;
				arr[j]='0';
			}
		}
		if(count>max)
		{
			max=count;
			result=arr[i];
			count=1;
		}
	}
	System.out.println(result);
	
}
}
