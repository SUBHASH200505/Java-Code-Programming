package Stringquestions;
import java.util.*;
public class CountStartingOne {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name1=sc.next();
	StringBuffer name=new StringBuffer(name1);
	int count=0;
	for(int i=0;i<name.length();i++)
	{
			if(name.charAt(i)=='1')
			{
				count++;
			}
	}
	int result=((count)*(count-1))/2;
	System.out.println(result);
			
}
}
