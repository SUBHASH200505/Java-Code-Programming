package Stringquestions;
import java.util.*;
public class UpperCase {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	String result=name.toUpperCase();
	System.out.println(result);
}
}
