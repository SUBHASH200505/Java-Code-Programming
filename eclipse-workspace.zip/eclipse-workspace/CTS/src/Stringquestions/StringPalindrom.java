package Stringquestions;
import java.util.*;
public class StringPalindrom {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	String result=name;
	int count=0;
	for(int i=0;i<name.length();i++)
	{
			if(name.charAt(i)==result.charAt(name.length()-i-1))
			{
			count++;	
			}
	}
	if(count==name.length())
	{
		System.out.println("Palindrom");
	}
	else
		System.out.println("Not Palidrom");
	/*StringBuffer str=new StringBuffer(name);
	str=str.reverse();
	if(name.equals(str.toString()))
		System.out.println("Palindrome");
	else
		System.out.println("Not Palindrome");*/
}
}
