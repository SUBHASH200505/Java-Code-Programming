package Stringquestions;
import java.util.*;
public class ReverseWord {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.nextLine();
	String[] result=name.split(" ");
	for(int i=result.length-1;i>=0;i--)
	{
		System.out.print(result[i]+" ");
	}
}
}
