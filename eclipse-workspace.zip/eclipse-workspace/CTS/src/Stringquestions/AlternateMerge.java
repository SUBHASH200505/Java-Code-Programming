package Stringquestions;
import java.util.*;
public class AlternateMerge {
public static void main(String[] args) {
	String s1="hello";
	String s2="world";
	String result="";
	for(int i=0;i<s1.length()||i<s2.length();i++)
	{
			result+=s1.charAt(i);
			result+=s2.charAt(i);
	}
	System.out.println(result);
}
}
