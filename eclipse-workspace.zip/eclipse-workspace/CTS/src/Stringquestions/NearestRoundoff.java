package Stringquestions;

import java.util.*;

public class NearestRoundoff {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int remainder = a % 10;
        int result;
        if (remainder <= 4) {
            result = a - remainder;
        } else {
            result = a + (10 - remainder);
        }
        System.out.println(result);
    }
}
