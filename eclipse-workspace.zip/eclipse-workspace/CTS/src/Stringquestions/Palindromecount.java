package Stringquestions;
import java.util.*;

public class Palindromecount {
    public static void main(String[] args) {
        String name = "ababd";
        int count = 0;
        for (int i = 0; i < name.length(); i++) {
            for (int j = i + 1; j <= name.length(); j++) { 
                String result = name.substring(i, j);
                if(result.length()<=1)
                	continue;
                String reversed = new StringBuffer(result).reverse().toString();  
                if (result.equals(reversed)) {
                    count++;
                }
            }
        }   
        System.out.println(count);
    }
}
