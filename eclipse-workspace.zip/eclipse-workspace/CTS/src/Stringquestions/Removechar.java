package Stringquestions;
import java.util.*;
public class Removechar {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	String name1=sc.next();
	StringBuffer str=new StringBuffer(name);
	for(int i=0;i<str.length();i++)
	{
		for(int j=0;j<name1.length();j++)
		{
			if(str.charAt(i)==name1.charAt(j))
				str=str.deleteCharAt(i);
		}
	}
	System.out.println(str.toString());
}
}
