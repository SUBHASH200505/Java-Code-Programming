package Stringquestions;
import java.util.*;
public class RemoveDuplicate {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	StringBuffer str=new StringBuffer(name);
	for(int i=0;i<str.length();i++)
	{
		for(int j=0;j<str.length();j++)
		{
			if(str.charAt(i)==str.charAt(j)&&i!=j)
			{
				str.deleteCharAt(j);
			}
		}
	}
	System.out.println(str.toString());
}
}
