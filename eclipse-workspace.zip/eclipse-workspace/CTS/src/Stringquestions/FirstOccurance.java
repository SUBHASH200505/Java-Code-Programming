package Stringquestions;
import java.util.*;
public class FirstOccurance {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	for(int i=0;i<name.length();i++)
	{
		for(int j=i+1;j<name.length();j++)
		{
			if(name.charAt(i)!=name.charAt(j))
			{
				System.out.println(name.charAt(i));
				return;
			}
	}
}
}
}


