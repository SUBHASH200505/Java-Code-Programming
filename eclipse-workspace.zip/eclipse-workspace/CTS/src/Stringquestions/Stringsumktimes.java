package Stringquestions;
import java.util.*;

public class Stringsumktimes {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name="zbax";
	int k=2;
	String result1="";
	char[] arr=name.toCharArray();
	int[] arr1=new int[arr.length];
	for(int i=0;i<arr.length;i++)
	{
		arr1[i]=arr[i]-96;
	}
	for(int i=0;i<arr.length;i++)
	{
	 result1+=arr1[i];
	}
	 String result =result1;
     while (k!=0) {
         int sum = 0;
         for (char ch : result.toCharArray()) {
             sum += ch - 96; 
         }
         result = Integer.toString(sum);
         k--;
     }

	
	System.out.println(result);
}
}
