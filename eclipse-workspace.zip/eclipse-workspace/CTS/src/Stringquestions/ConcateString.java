package Stringquestions;
import java.util.*;
public class ConcateString {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	String name=sc.next();
	String result="";
	int a=sc.nextInt();
	for(int i=0;i<a;i++)
	{
		result+=name;
	}
	System.out.println(result);
}
}
